import java.util.Arrays;

/*在n个物品中挑选若干物品装入背包，最多能装多满？假设背包的大小为m，每个物品的大小为A[i]
        样例
        样例 1:
        输入:  [3,4,8,5], backpack size=10
        输出:  9
        样例 2:
        输入:  [2,3,5,7], backpack size=12
        输出:  12
        挑战
        O(n x m) 的时间复杂度 and O(m) 空间复杂度
        如果不知道如何优化空间O(n x m) 的空间复杂度也可以通过.
        注意事项
        你不可以将物品进行切割。*/
public class BackPack {
    public int backPack(int m, int[] A) {
        /*int size = A.length, i = 0, j = 0;
        if(size <= 0) {
            return 0;
        }
        int[] dp = new int[m+1];
        for(i=0; i<m+1; i++) {
            dp[i] = 0;
        }
        System.out.println(Arrays.toString(dp));
        for(i=0; i<size; i++) {
            for(j=m; j>=1; j--) {
                if(j >= A[i]) {
                    dp[j] = Math.max(dp[j], dp[j - A[i]] + A[i]);
                }
            }
        }
        return dp[m];*/
        int size=A.length;
        int i=0,j=0;
        if(size<=0){
            return 0;
        }
        int[] dp=new int[m+1];
        Arrays.fill(dp,0);
        System.out.println(Arrays.toString(dp));
        for(i=0;i<size;i++){
            for(j=m;j>=1;j--){
                if(j>=A[i]){
                    dp[j]=Math.max(dp[j],dp[j-A[i]]+A[i]);
                }
            }
        }
        return dp[m];
    }

    public static void main(String[] args) {
        int[] A=new int[]{3,4,8,5};
        BackPack backPack=new BackPack();
        System.out.println(backPack.backPack(10,A));
    }
}
