import java.util.*;

/*在给定的数组中，找到出现次数最多的数字。
        出现次数相同时，返回数值最小的数字。
        样例
        Example 1:
        Input:
        [1,1,2,3,3,3,4,5]
        Output:
        3
        Example 2:
        Input:
        [1]
        Output:
        1
        注意事项
        数组长度不超过100000。
        0 <= a[i] <= 2147483647*/
public class FindNumber {
    public int findNumber(int[] array) {
        /*int temp=0;
        for(int m=0;m<array.length;m++) {
            for (int i = 0; i < array.length - 1; i++) {
                if (array[i] > array[i + 1]) {
                    temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
                }
            }
        }
        //System.out.println(Arrays.toString(array));
        int m=0,n=0,index=0;
        for(int i=0;i<array.length-1;i++){
            if(array[i]==array[i+1]){
                m++;
                if(m>n) {
                    n = m;
                    index = i;
                }
            }else{
                m=0;
            }
        }
        return array[index];*/
        HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
        int temp=0;
        for(int m=0;m<array.length;m++) {
            for (int i = 0; i < array.length - 1; i++) {
                if (array[i] > array[i + 1]) {
                    temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(array));
        for(int i = 0; i < array.length; i++)
        {
            if(map.containsKey(array[i]))
            {
                int formerValue = map.get(array[i]);
                map.put(array[i], formerValue + 1);    // 该数字出现的次数加1
            }
            else
            {
                map.put(array[i], 1);    // 该数字第一次出现
            }
        }
        System.out.println(map);
        Collection<Integer> count = map.values();
        System.out.println(count);
        int maxCount = Collections.max(count);
        int maxNumber = 0;
        for(Map.Entry<Integer, Integer> entry : map.entrySet())
        {
            if(entry.getValue() == maxCount)
            {
                maxNumber = entry.getKey();
                break;
            }
        }
        return maxNumber;
    }

    public static void main(String[] args) {
        int[] array={3,3,3,5,5,5,1,1,2,4};
        FindNumber findNumber=new FindNumber();
        System.out.println(findNumber.findNumber(array));
    }
}
