import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/*在一个排序数组中找一个数，返回该数出现的任意位置，如果不存在，返回 -1。
        样例
        Example 1:
        Input: nums = [1,2,2,4,5,5], target = 2
        Output: 1 or 2
        Example 2:
        Input: nums = [1,2,2,4,5,5], target = 6
        Output: -1
        挑战
        O(logn) 的时间*/
public class FindPosition {
    public int findPosition(int[] nums, int target) {
        try{
            int start=0;
            int end=nums.length-1;
            List<Integer> list=Arrays.stream(nums).boxed().collect(Collectors.toList());
            if(nums[nums.length-1]<target||nums[0]>target||!list.contains(target)){
                start=nums[nums.length-1]/0;
            }
            while ((start<=end)) {
                int mid = (start + end) / 2;
                if(nums[mid]>target){
                    end=mid;
                }
                if(nums[mid]<target){
                    start=mid;
                }
                if(nums[mid]==target){
                    return mid;
                }
            }
        }catch (Exception e){
            System.out.println("We can't find target.");
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] nums=new int[]{1,2,3,4,5,7,8,9};
        FindPosition findPosition=new FindPosition();
        System.out.println(findPosition.findPosition(nums,6));
        //List<Integer> list=Arrays.stream(nums).boxed().collect(Collectors.toList());
        //System.out.println(list.contains(6));
    }
}
