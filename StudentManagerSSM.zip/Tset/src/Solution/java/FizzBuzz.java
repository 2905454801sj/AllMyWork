import java.util.*;

/*给你一个整数n. 从 1 到 n 按照下面的规则打印每个数：

        如果这个数被3整除，打印fizz.
        如果这个数被5整除，打印buzz.
        如果这个数能同时被3和5整除，打印fizz buzz.
        如果这个数既不能被 3 整除也不能被 5 整除，打印数字本身。
        样例
        比如 n = 15, 返回一个字符串数组：

        [
        "1", "2", "fizz",
        "4", "buzz", "fizz",
        "7", "8", "fizz",
        "buzz", "11", "fizz",
        "13", "14", "fizz buzz"
        ]
        挑战
        你是否可以只用一个 if 来实现*/
public class FizzBuzz {
    public List<String> fizzBuzz(int n) {
        //1.0
        /*List<String> strings = new ArrayList<>();
        for(int i=1;i<n+1;i++) {
            if(i%15==0){
                strings.add("fizz buzz");
            }else if(i%3==0){
                strings.add("fizz");
            }else if(i%5==0){
                strings.add("buzz");
            }else {
                strings.add(Integer.toString(i));
            }
        }
        return strings;*/
        //2.0
        List<String> value = new ArrayList();
        Map m1 = new HashMap();
        m1.put(5, " buzz");
        Map m2 = new HashMap();
        m2.put(3, "fizz ");
        for (int i = 1; i <= n; i ++) {
            String string2 = (String)m2.get(i%3+3);
            String string1 = (String)m1.get(i%5+5);
            string1 = string2 + string1;
            string1 = string1.replaceFirst(" ", "");
            string1 = string1.replaceAll("null", "");
            if(string1.length() == 0) {
                string1 = String.valueOf(i);
            }
            value.add(string1);
        }
        return value;
    }
    public static void main(String[] args) {
        FizzBuzz fizzBuzz = new FizzBuzz();
        List<String> strings=fizzBuzz.fizzBuzz(30);
        for(int i=0;i<30;i++){
            System.out.println(strings.get(i));
        }
    }
}
