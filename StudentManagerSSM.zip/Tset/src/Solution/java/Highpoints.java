/*给一个n*m大小的矩阵，寻找矩阵中所有比邻居（上下左右，对角也算，不考虑边界就是8个咯）都严格大的点。
        返回一个n*m大小的矩阵，如果原矩阵中的点比邻居都严格大，则该位置为1，反之为0。
        样例
        样例 1
        输入:
        1 2 3
        4 5 8
        9 7 0
        输出:
        0 0 0
        0 0 1
        1 0 0
        注意事项
        1 \leq n,m \leq 1001≤n,m≤100*/
public class Highpoints {
    public int[][] highpoints(int[][] grid) {
        // write your code here
        final int[][] ps = new int[][]{new int[]{-1,-1}, new int[]{-1, 0}, new int[]{0, -1}, new int[]{0, 1}, new int[]{1,-1}, new int[]{1,0}, new int[]{1,1}};
        if (grid == null) {
            return grid;
        }
        int r = grid.length;
        if (r == 0) {
            return grid;
        }
        int c = grid[0].length;
        if (c == 0) {
            return grid;
        }
        int[][] ret = new int[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                boolean max = true;
                for (int[] p : ps) {
                    int row = p[0] + i;
                    int col = p[1] + j;
                    if (row >= 0
                            && row < r
                            && col >=0
                            && col < c) {
                        if (grid[row][col] >= grid[i][j]) {
                            max = false;
                            break;
                        }
                    }
                }
                if (max) {
                    ret[i][j] = 1;
                } else {
                    ret[i][j] = 0;
                }
            }
        }

        return ret;

    }

    public static void main(String[] args) {
        int[][] nums={{9,2,3},{4,2,6},{7,8,9}};
        Highpoints highpoints=new Highpoints();
        int[][] a=highpoints.highpoints(nums);
        for (int[] as:a) {
            System.out.println();
            for (int ass:as) {
                System.out.print(ass+" ");
            }
        }
    }
}
