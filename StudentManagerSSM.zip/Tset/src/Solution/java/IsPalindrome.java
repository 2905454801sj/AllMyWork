import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/*给定一个字符串，判断其是否为一个回文串。只考虑字母和数字，忽略大小写。
        样例
        样例 1:
        输入: "A man, a plan, a canal: Panama"
        输出: true
        解释: "amanaplanacanalpanama"
        样例 2:
        输入: "race a car"
        输出: false
        解释: "raceacar"
        挑战
        O(n) 时间复杂度，且不占用额外空间。
        注意事项
        你是否考虑过，字符串有可能是空字符串？这是面试过程中，面试官常常会问的问题。
        在这个题目中，我们将空字符串判定为有效回文。*/
public class IsPalindrome {
    public boolean isPalindrome(String s) {
        if(s.length()==0){
            return true;
        }
        s=s.replaceAll("(?i)[^a-zA-Z0-9\u4E00-\u9FA5]", "");
        s=s.toLowerCase();
        System.out.println(s);
        List<Character> list=new ArrayList<>();
        for(int i=0;i<s.length();i++){
            list.add(s.charAt(i));
        }
        Collections.reverse(list);
        StringBuilder stringBuilder=new StringBuilder();
        for(int i=0;i<s.length();i++){
            stringBuilder.append(list.get(i));
        }
        String ss=stringBuilder.toString();
        System.out.println(ss);
        return ss.equals(s);
    }

    public static void main(String[] args) {
        String s="AmanaplanaCanalpanama";
        IsPalindrome isPalindrome=new IsPalindrome();
        System.out.println(isPalindrome.isPalindrome(s));
    }
}
