/*给定一个二叉树，判断它是否是合法的二叉查找树(BST)
        一棵BST定义为：
        节点的左子树中的值要严格小于该节点的值。
        节点的右子树中的值要严格大于该节点的值。
        左右子树也必须是二叉查找树。
        一个节点的树也是二叉查找树。
        样例
        样例 1:
        输入：{-1}
        输出：true
        解释：
        二叉树如下(仅有一个节点）:
        -1
        这是二叉查找树。
        样例 2:
        输入：{2,1,4,#,#,3,5}
        输出：true
        解释：
        二叉树如下：
          2
         / \
        1   4
           / \
          3   5
        这是二叉查找树。*/
class TreeNode {
      public int val;
      public TreeNode left, right;
      public TreeNode(int val) {
          this.val = val;
          this.left = this.right = null;
      }
 }
public class IsValidBST {
    public boolean isValidBST(TreeNode root) {
        if(root==null){
            return true;
        }
        return isright(root)&&isleft(root)&&near(root);
    }
    public static boolean isright(TreeNode treeNode){
        if(treeNode.right==null){
            return true;
        }
        if(treeNode.val>treeNode.right.val){
            isright(treeNode.right);
        }
        else{
            return false;
        }
        return true;
    }
    public static boolean isleft(TreeNode treeNode){
        if(treeNode.left==null){
            return true;
        }
        if(treeNode.val<treeNode.left.val){
            isright(treeNode.left);
        }
        else{
            return false;
        }
        return true;
    }
    public static boolean near(TreeNode treeNode){
        if(treeNode.right==null||treeNode.left==null){
            return true;
        }
        if(treeNode.right.val<treeNode.left.val){
            near(treeNode.right);
            near(treeNode.left);
        }else{
            return false;
        }
        return true;
    }

    public static void main(String[] args) {
        TreeNode treeNode=new TreeNode(2);
        treeNode.right=new TreeNode(1);
        treeNode.left=new TreeNode(4);
        /*treeNode.left.right=new TreeNode(3);
        treeNode.left.left=new TreeNode(5);*/
        IsValidBST isValidBST=new IsValidBST();
        System.out.println(isValidBST.isValidBST(treeNode));
    }
}
