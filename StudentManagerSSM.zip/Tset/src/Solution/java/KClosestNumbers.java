import java.util.*;

/*给一个目标数 target, 一个非负整数 k, 一个按照升序排列的数组 A。在A中找与target最接近的k个整数。返回这k个数并按照与target的接近程度从小到大排序
  如果接近程度相当，那么小的数排在前面。
        样例
        Example 1:
        Input: A = [1, 2, 3], target = 2, k = 3
        Output: [2, 1, 3]
        Example 2:
        Input: A = [1, 4, 6, 8], target = 3, k = 3
        Output: [4, 1, 6]
        挑战
        O(logn + k) 的时间复杂度*/
public class KClosestNumbers {
    public int[] kClosestNumbers(int[] A, int target, int k) {
        /*if(A==null || A.length==0)
            return null;
        int l = binarySearch(A, target);
        int r = l + 1;
        int[] res = new int[k];
        int resNum = 0;
        for(int i=0; i<k; i++){
            if(isLeftColser(A, target, l, r)){
                res[i] = A[l--];
            }else
                res[i] = A[r++];
        }
        return res;*/
        if(A.length==0||A==null){
            return A;
        }
        int left=binarySearch(A,target);
        int right=left+1;
        int[] res=new int[k];
        for(int i=0;i<k;i++) {
            if (isLeftColser(A, target, left, right)) {
                res[i]=A[left--];
            }else{
                res[i]=A[right++];
            }
        }
        return res;
    }
    private boolean isLeftColser(int[] A, int target, int l, int r){
        /*if(l < 0)
            return false;
        if(r > A.length-1)
            return true;
        if(target-A[l] <= A[r]-target)
            return true;
        return false;*/
        if(l<0){
            return false;
        }
        if(r>A.length-1){
            return true;
        }
        if(target-A[l]<=A[r]-target){
            return true;
        }
        return false;
    }
    private int binarySearch(int[] A, int target){
        int l = 0;
        int r = A.length-1;
        while(l+1 < r){
            int mid = l + (r-l)/2;
            if(A[mid] == target)
                return mid;
            else if(A[mid] > target)
                r = mid;
            else
                l = mid;
        }
        return l;
    }
    public static void main(String[] args) {
        int[] A=new int[]{1,2, 4, 6, 8};
        KClosestNumbers kClosestNumbers=new KClosestNumbers();
        System.out.println(Arrays.toString(kClosestNumbers.kClosestNumbers(A,3,3)));
    }
}
