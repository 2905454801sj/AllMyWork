import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/*在数组中找到第 k 大的元素。
        样例
        样例 1：
        输入：
        n = 1, nums = [1,3,4,2]
        输出：
        4
        样例 2：
        输入：
        n = 3, nums = [9,3,2,4,8]
        输出：
        4
        挑战
        要求时间复杂度为O(n)，空间复杂度为O(1)。
        注意事项
        你可以交换数组中的元素的位置*/
public class KthLargestElement {
    public int kthLargestElement(int n, int[] nums) {
        //处理大容量数组易出错
        /*Arrays.sort(nums);
        HashSet<Integer> set=new HashSet<>();
        for(int i=0;i<nums.length;i++){
            set.add(nums[i]);
        }
        return (int)set.toArray()[set.size()-n];*/
        int left = 0, right = nums.length - 1;
        while (true) {
            int pos = partition(nums, left, right);
            if (pos == n - 1) {
                return nums[pos];
            } else if (pos > n - 1){
                right = pos - 1;
            } else {
                left = pos + 1;
            }
        }
    }
    private int partition(int[] nums,int l,int r)
    {
        int i=l,x=nums[l];
        int j=r;
        while(i<j) {
            while(i<j&&nums[j]<x) {
                j--;
            }
            if(i<j) {
                nums[i++] = nums[j];
            }
            while(i<j&&nums[i]>=x) {
                i++;
            }
            if(i<j) {
                nums[j--] = nums[i];
            }
        }
        nums[i]=x;
        return i;
    }

    public static void main(String[] args) {
        int[] nums=new int[]{3,2,9,4,8};
        KthLargestElement kthLargestElement=new KthLargestElement();
        System.out.println(kthLargestElement.kthLargestElement(1,nums));
    }
}
