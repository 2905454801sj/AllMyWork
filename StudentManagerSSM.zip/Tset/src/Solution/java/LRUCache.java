import java.util.*;
import java.util.logging.Handler;

/*为最近最少使用（LRU）缓存策略设计一个数据结构，它应该支持以下操作：获取数据和写入数据。
        get(key) 获取数据：如果缓存中存在key，则获取其数据值（通常是正数），否则返回-1。
        set(key, value) 写入数据：如果key还没有在缓存中，则写入其数据值。当缓存达到上限，它应该在写入新数据之前删除最近最少使用的数据用来腾出空闲位置。
        最终, 你需要返回每次 get 的数据.
        样例
        样例 1:
        输入：
        LRUCache(2)
        set(2, 1)
        set(1, 1)
        get(2)
        set(4, 1)
        get(1)
        get(2)
        输出：[1,-1,1]
        解释：
        cache上限为2，set(2,1)，set(1, 1)，get(2) 然后返回 1，set(4,1) 然后 delete (1,1)，因为 （1,1）最少使用，get(1) 然后返回 -1，get(2) 然后返回 1。
        样例 2:
        输入：
        LRUCache(1)
        set(2, 1)
        get(2)
        set(3, 2)
        get(2)
        get(3)
        输出：[1,-1,2]
        解释：
        cache上限为 1，set(2,1)，get(2) 然后返回 1，set(3,2) 然后 delete (2,1)，get(2) 然后返回 -1，get(3) 然后返回 2。*/
public class LRUCache {
    private int capacity;
    private LRULinkedHashMap<Integer, Integer> lruLinkedHashMap = new LRULinkedHashMap<>();
    private class LRULinkedHashMap<K, V> extends LinkedHashMap<K, V> {
        protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
            if (size() > capacity) {
                return true;
            } else {
                return false;
            }
        }
    }

    /*
     * @param capacity: An integer
     */
    public LRUCache(int capacity) {
        this.capacity=capacity;
    }

    /*
     * @param key: An integer
     * @return: An integer
     */
    public int get(int key) {
        Integer value = lruLinkedHashMap.get(key);
        if (null == value) {
            return -1;
        }
        lruLinkedHashMap.remove(key);
        lruLinkedHashMap.put(key, value);
        return value;

    }

    /*
     * @param key: An integer
     * @param value: An integer
     * @return: nothing
     */
    public void set(int key, int value) {
        if (lruLinkedHashMap.containsKey(key)) {
            lruLinkedHashMap.remove(key);
        }
        lruLinkedHashMap.put(key, value);
    }
}
