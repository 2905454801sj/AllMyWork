import java.util.*;

/*给出两个单词（start和end）和一个字典，找出从start到end的最短转换序列，输出最短序列的长度。
        变换规则如下：
        每次只能改变一个字母。
        变换过程中的中间单词必须在字典中出现。(起始单词和结束单词不需要出现在字典中)
        样例
        样例 1:
        输入：start = "a"，end = "c"，dict =["a","b","c"]
        输出：2
        解释：
        "a"->"c"
        样例 2:
        输入：start ="hit"，end = "cog"，dict =["hot","dot","dog","lot","log"]
        输出：5
        解释：
        "hit"->"hot"->"dot"->"dog"->"cog"
        如果不存在这样的转换序列，返回 0。
        所有单词具有相同的长度。
        所有单词只由小写字母组成。
        字典中不存在重复的单词。
        你可以假设 beginWord 和 endWord 是非空的，且二者不相同*/
public class LadderLength {
    public int ladderLength(String start, String end, Set<String> dict) {
        /*if(start.equals(end)) return 1;
        Queue<String> que=new LinkedList<>();
        int visited[]=new int [dict.size()];
        Object a[]=dict.toArray();
        que.add(start);
        que.add("!");
        int count=0;
        boolean flag=false;
        while(!que.isEmpty())
        {
            String temp=que.poll();
            if(temp.equals("!")) {
                count++;
                continue;
            }
            if(iswork(temp, end))
            {
                flag=true;
                count+=2;
                break;
            }
            for(int i=0;i<visited.length;i++)
            {
                if(visited[i]==0&&iswork(temp, a[i].toString()))
                {
                    que.add(a[i].toString());
                    visited[i]=1;
                }
            }
            if(que.peek().equals("!"))//只有前一层全部poll了
                //漏出"!"时，才再加一个特殊符号
                //少了if则加特殊符号的隔离作用就消失了
                que.add("!");
        }
        if(flag==false) return 0;//如果没找到解
        return count;//找到了就返回值*/
        if(start==end){
            return 1;
        }
        Queue<String> queue=new LinkedList<>();
        Object[] a=dict.toArray();
        int[] as=new int[dict.size()];
        int count=0;
        queue.add(start);
        queue.add("!");
        while(queue!=null){
            String temp=queue.poll();
            if(temp=="!"){
                count++;
                continue;
            }
            if(iswork(temp,end)){
                count=count+2;
                return count;
            }
            for(int i=0;i<a.length;i++){
                if(as[i]==0&&iswork(temp,(String)a[i])){
                    queue.add(a[i].toString());
                    as[i]=1;
                }
            }
            if(queue.peek()=="!"){
                queue.add("!");
            }
        }
        return 0;
    }
    public static boolean iswork(String a,String b){
        if(a==null||b==null){
            return false;
        }
        int count=0;
        for(int i=0,j=0;i<a.length()&&j<b.length();i++,j++){
            if(a.charAt(i)!=b.charAt(j)){
                count++;
            }
        }
        if(count==1){
            return true;
        }else{
            return false;
        }
    }

    public static void main(String[] args) {
        Set<String> dict=new HashSet<>();
        dict.add("ts");
        dict.add("sc");
        dict.add("ph");
        dict.add("ca");
        dict.add("jr");
        dict.add("hr");
        dict.add("to");
        dict.add("if");
        dict.add("ha");
        dict.add("is");
        dict.add("io");
        dict.add("cf");
        dict.add("ta");
        String start="if";
        String end="ta";
        LadderLength ladderLength=new LadderLength();
        System.out.println(ladderLength.ladderLength(start,end,dict));
    }
}
