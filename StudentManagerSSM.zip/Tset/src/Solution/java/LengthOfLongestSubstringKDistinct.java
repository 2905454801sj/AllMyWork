import java.util.*;

/*给定字符串S，找到最多有k个不同字符的最长子串T。
        样例
        样例 1:
        输入: S = "eceba" 并且 k = 3
        输出: 4
        解释: T = "eceb"
        样例 2:
        输入: S = "WORLD" 并且 k = 4
        输出: 4
        解释: T = "WORL" 或 "ORLD"
        挑战
        O(n) 时间复杂度*/
public class LengthOfLongestSubstringKDistinct {
    public int lengthOfLongestSubstringKDistinct(String s, int k) {
        /*char [] ch = s.toCharArray();
        int [] arr = new int[256];
        Arrays.fill(arr,0);
        int maxLen = 0;
        int count = 0;
        int i , j = 0 ;
        for( i = 0 ; i < s.length() ; i ++){
            while( j < s.length() && count <= k){
                arr[ch[j]]++;
                if(arr[ch[j]]==1){
                    count++;
                }
                if(count > k){
                    arr[ch[j]]--;
                    count--;
                    break;
                }
                j++;
            }
            maxLen = (j-i)>maxLen?(j-i):maxLen;
            arr[ch[i]]--;
            System.out.println(count);
            if(arr[ch[i]]==0){
                count--;
            }
        }
        return maxLen;*/
        char[] a=s.toCharArray();
        int[] arr=new int[256];
        int i,j=0;
        int count=0;
        int maxlen=0;
        for(i=0;i<s.length();i++){
            while(j<s.length()&&count<=k){
                arr[a[j]]++;
                if(arr[a[j]]==1){
                    count++;
                }
                if(count>k){
                    arr[a[j]]--;
                    count--;
                    break;
                }
                j++;
            }
            maxlen=(j-i)>maxlen?(j-i):maxlen;
            arr[a[i]]--;
            if(arr[a[i]]==0){
                count--;
            }
        }
        return maxlen;
    }
    public static void main(String[] args) {
        String s="eced";
        LengthOfLongestSubstringKDistinct lengthOfLongestSubstringKDistinct=new LengthOfLongestSubstringKDistinct();
        System.out.println(lengthOfLongestSubstringKDistinct.lengthOfLongestSubstringKDistinct(s,2));
    }
}
