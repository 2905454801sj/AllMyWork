import javax.annotation.processing.SupportedSourceVersion;
import java.util.*;

/*给定一个整数序列，找到最长上升子序列（LIS），返回LIS的长度。
        样例
        样例 1:
        输入:  [5,4,1,2,3]
        输出:  3
        解释:
        LIS 是 [1,2,3]
        样例 2:
        输入: [4,2,4,5,3,7]
        输出:  4
        解释:
        LIS 是 [2,4,5,7]
        挑战
        要求时间复杂度为O(n^2) 或者 O(nlogn)
        说明
        最长上升子序列的定义：
        最长上升子序列问题是在一个无序的给定序列中找到一个尽可能长的由低到高排列的子序列，这种子序列不一定是连续的或者唯一的。*/
public class LongestIncreasingSubsequence {
    public int longestIncreasingSubsequence(int[] nums) {
        /*if(nums.length==0){
            return 0;
        }
        int[] dp=new int[nums.length];
        int max=1;
        dp[0]=1;
        for(int i=1;i<nums.length;i++){
            dp[i]=1;
            for(int j=0;j<i;j++){
                if(nums[i]>nums[j]){
                    dp[i]=Math.max(dp[i],dp[j]+1);
                    max=Math.max(max,dp[i]);
                }
            }
        }
        return max;*/
        if(nums.length==0||nums==null){
            return 0;
        }
        int max=1;
        int[] dp=new int[nums.length];
        dp[0]=1;
        for(int i=1;i<nums.length;i++){
            dp[i]=1;
            for(int j=0;j<i;j++){
                if(nums[i]>nums[j]){
                    dp[i]=Math.max(dp[i],dp[j]+1);
                    max=Math.max(max,dp[i]);
                }
            }
        }
        return max;
    }

    public static void main(String[] args) {
        int[] nums=new int[]{88,4,24,82,86};
        LongestIncreasingSubsequence longestIncreasingSubsequence=new LongestIncreasingSubsequence();
        System.out.println(longestIncreasingSubsequence.longestIncreasingSubsequence(nums));
        /*Arrays.sort(nums);
        System.out.println(Arrays.toString(nums));*/
    }
}
