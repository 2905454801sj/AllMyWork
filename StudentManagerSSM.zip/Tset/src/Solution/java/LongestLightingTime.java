import java.util.*;
import java.util.stream.IntStream;

public class LongestLightingTime {
    /*
    有一排 26 个彩灯，编号从 0 到 25，现在给出了一系列控制指令来
    控制这些彩灯的开关。 一开始这些彩灯都是关闭的，然后指令将逐条发出
    。 在每条指令operation[i]中含有两个整数 operation[i][0], operation[i][1]。
    在接收到一条指令时，标号为 operation[i][0] 的彩灯会亮起，
    直到第 operation[i][1] 秒的时候熄灭。当灯熄灭后，下一条指令将会发出。
    也就是说，任何时候只会有一盏灯亮着。 其中第一条指令将在第0秒的时候发出，并被立刻执行。
    你的任务是找到哪个彩灯单次亮起的时间最长。
    (0≤i<n) 保证至少有一个按键. 保证 keyTimes 是按照 keyTimes[i][1] 升序排序的.
    样例 1
    输入：
    [[0,2],[1,5],[0,9],[2,15]]
    输出：
    'c'
    说明：
    operation = `[[0, 2], [1, 5], [0, 9], [2, 15]]`
    在第0秒的时候，接收到指令`[0, 2]`，此时标号为 0 的灯亮起，第 2 秒的时候熄灭。此时 0号灯 的单次亮起时间为`2-0 = 2` 秒。
    在第2秒的时候，接收到指令`[1, 5]`，此时标号为 1 的灯亮起，第 5 秒的时候熄灭。此时 1号灯 的单次亮起时间为 `5-2 = 3` 秒。
    在第5秒的时候，接收到指令`[0, 9]`，此时标号为 0 的灯亮起，第 9 秒的时候熄灭。此时 0号灯 的单次亮起时间为 `9-5 = 4` 秒。
    在第9秒的时候，接收到指令`[2, 15]`，此时标号为 2 的灯亮起，第 15 秒的时候熄灭。此时 2号灯 的单次亮起时间为 `15-9 = 6` 秒。
    所以单次亮起的最长时间为 `max(2, 3, 4, 6) = 6` 秒，是标号为 `2` 的彩灯。
    你需要返回一个小写英文字`如 'a' 代表 0，'b' 代表 1，'c' 代表 2 ... 'z' 代表 25。`
    所以你的答案应该是`'c'`
     */
    public char longestLightingTime(List<List<Integer>> operation) {
        /*HashMap<Integer,Integer> hashMap=new HashMap<>();
        int[] a=new int[operation.size()];
        for(int i=0;i<operation.size();i++){
            if(i==0) {
                a[0] = operation.get(0).get(1);
            }else{
                a[i]=operation.get(i).get(1)-operation.get(i-1).get(1);
            }
            hashMap.put(operation.get(i).get(0),a[i]);
        }
        int max=0;
        int temp=0;
        for(int i=0;i<a.length;i++){
            max=Math.max(a[i],max);
        }
        Iterator<Map.Entry<Integer,Integer>> iterator=hashMap.entrySet().iterator();
        Map.Entry<Integer,Integer> entry=iterator.next();
        for(Integer key: hashMap.keySet()){
            if(hashMap.get(key).equals(max)){
                temp=key;
            }
        }
        char c=(char)(97+temp);
        return c;*/
        int totalTime   = 0;
        int maxTime     = 0;
        int maxTimeCode = 0;

        for (List<Integer> o : operation) {
            int time = o.get(1) - totalTime;
            totalTime += time;

            if (time > maxTime) {
                maxTime = time;
                maxTimeCode = o.get(0);
            }
        }
        return (char) ('a' + maxTimeCode);
    }

    public static void main(String[] args) {
        LongestLightingTime longestLightingTime=new LongestLightingTime();
        List<Integer> list=new ArrayList<>();
        List<Integer> list1=new ArrayList<>();
        List<Integer> list2=new ArrayList<>();
        List<Integer> list3=new ArrayList<>();
        list.add(0);
        list.add(2);
        list1.add(1);
        list1.add(5);
        list2.add(0);
        list2.add(9);
        list3.add(2);
        list3.add(15);
        List<List<Integer>> operation=new ArrayList<>();
        operation.add(list);
        operation.add(list1);
        operation.add(list2);
        operation.add(list3);
        Optional.of(longestLightingTime.longestLightingTime(operation)).ifPresent(System.out::println);
    }
}
