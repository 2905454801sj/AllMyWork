import java.util.*;

/*给出一个字符串（假设长度最长为1000），求出它的最长回文子串，你可以假定只有一个满足条件的最长回文串。
        样例
        样例 1:
        输入:"abcdzdcab"
        输出:"cdzdc"
        样例 2:
        输入:"aba"
        输出:"aba"
        挑战
        O(n2) 时间复杂度的算法是可以接受的，如果你能用 O(n) 的算法那自然更好。*/
public class LongestPalindrome {
    public String longestPalindrome(String s) {
        /*List<Character> list=new ArrayList<>();
        for (int i=0;i<s.length();i++){
            list.add(s.charAt(i));
        }
        Collections.reverse(list);
        StringBuilder stringBuilder=new StringBuilder();
        for(int i=0;i<list.size();i++){
            stringBuilder.append(list.get(i));
        }
        String as=stringBuilder.toString();
        String max="",min="";
        max=(s.length()>as.length())?s:as;
        min=(max==s)?as:s;
        for(int x=0;x<min.length();x++){
            for(int y=0,z=min.length()-x;z!=min.length()+1;y++,z++){
                String temp=min.substring(y,z);
                // sp(temp);
                if(max.contains(temp)){	// if(max.indexOf(temp)!=-1)
                    return temp;
                }
            }
        }
        return "";*/
        String res = "";
        //奇数形式回文
        for(int i=0; i<s.length(); i++){
            String temp = null;
            int l=i, r=i;
            for(; l>=0&&r<s.length(); l--,r++){
                if(s.charAt(l) != s.charAt(r))
                    break;
            }
            temp = s.substring(l+1, r);
            //System.out.println(temp.length());
            if(temp.length() > res.length())
                res = temp;
        }
        System.out.println(res);
        //偶数形式回文
        for(int i=0; i<s.length()-1; i++){
            String temp = null;
            int l=i, r=i+1;
            for(; l>=0 && r<s.length(); l--,r++){
                if(s.charAt(l) != s.charAt(r))
                    break;
            }
            temp = s.substring(l+1, r);
            //System.out.println(temp.length());
            if(temp.length() > res.length())
                res = temp;
        }
        //System.out.println(s.length()%2);
        return res;
    }

    public static void main(String[] args) {
        String s="abbbb";
        LongestPalindrome longestPalindrome=new LongestPalindrome();
        System.out.println(longestPalindrome.longestPalindrome(s));
    }
}
