import java.util.*;

/*给定一个整型数组，找出主元素，它在数组中的出现次数严格大于数组元素个数的二分之一。
        样例
        样例 1:
        输入: [1, 1, 1, 1, 2, 2, 2]
        输出: 1
        样例 2:
        输入: [1, 1, 1, 2, 2, 2, 2]
        输出: 2
        挑战
        要求时间复杂度为O(n)，空间复杂度为O(1)
        注意事项
        你可以假设数组非空，且数组中总是存在主元素。*/
public class MajorityNumber {
    public int majorityNumber(List<Integer> nums) {
        Collections.sort(nums);
        return nums.get(nums.size()/2);
    }

    public static void main(String[] args) {
        List<Integer> nums=new ArrayList<>();
        nums.add(2);
        nums.add(1);
        nums.add(2);
        nums.add(1);
        nums.add(2);
        MajorityNumber majorityNumber=new MajorityNumber();
        int a=majorityNumber.majorityNumber(nums);
        System.out.println(a);
    }
}
