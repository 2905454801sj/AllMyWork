/*给定一个整数数组，找到一个具有最大和的子数组，返回其最大和。
        样例
        样例1:
        输入：[−2,2,−3,4,−1,2,1,−5,3]
        输出：6
        解释：符合要求的子数组为[4,−1,2,1]，其最大和为 6。
        样例2:
        输入：[1,2,3,4]
        输出：10
        解释：符合要求的子数组为[1,2,3,4]，其最大和为 10。
        挑战
        要求时间复杂度为O(n)
        注意事项
        子数组最少包含一个数*/
public class MaxSubArray {
    public int maxSubArray(int[] nums) {
        int n=nums.length;
        for(int i=1;i<n;i++){
            nums[i]+=nums[i-1];
        }
        int min=0;
        int dp=nums[0];
        for(int i=0;i<n;i++){
            dp=Math.max(dp,nums[i]-min);
            if(nums[i]<min){
                min=nums[i];
            }
        }
        return dp;

        /*更优方法
        int res=nums[0];
        int dp=0;
        for(int num:nums){
            if(dp>0){
                dp+=num;
            }else{
                dp=num;
            }
            res=Math.max(res,dp);
        }
        return res;
        */
    }

    public static void main(String[] args) {
        int[] nums={1,2,3,-10,-3,4,5,-2,4,-8,8};
        MaxSubArray maxSubArray=new MaxSubArray();
        int a=maxSubArray.maxSubArray(nums);
        System.out.println(a);
    }
}
