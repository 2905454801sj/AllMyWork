import java.util.Arrays;
import java.util.stream.StreamSupport;


/*合并两个有序升序的整数数组A和B变成一个新的数组。新数组也要有序。

        样例
        样例 1:

        输入: A=[1], B=[1]
        输出:[1,1]
        样例解释: 返回合并后的数组。
        样例 2:

        输入: A=[1,2,3,4], B=[2,4,5,6]
        输出: [1,2,2,3,4,4,5,6]
        样例解释: 返回合并后的数组。*/
public class MergeSortArrayII {
    public int[] mergeSortedArray(int[] A, int[] B) {
        int m = 0,n=0;
        int[] C = new int[A.length+B.length];
        int[] temp;
        for(int i=0;i<C.length;i++){
            while(m==A.length){
                C[i]=B[n];
                n++;
                i++;
                if(n==B.length){
                    return C;
                }
            }
            while(n==B.length){
                C[i]=A[m];
                m++;
                i++;
                if(m==A.length){
                    return C;
                }
            }
            if(A[m]<=B[n]){
                C[i]=A[m];
                m++;
            }else{
                C[i]=B[n];
                n++;
            }
        }
        return C;
    }
    public static void main(String[] args) {
        int[] A={1,5};
        int[] B={2,3};
        MergeSortArrayII mergeSortArrayII=new MergeSortArrayII();
        int[] c=mergeSortArrayII.mergeSortedArray(A,B);
        System.out.println(Arrays.toString(c));
    }
}
