import java.util.List;
/*给定一个整数数组，找到一个具有最小和的连续子数组。返回其最小和。
        样例
        样例 1
        输入：[1, -1, -2, 1]
        输出：-3
        样例 2
        输入：[1, -1, -2, 1, -4]
        输出：-6
        注意事项
        子数组最少包含一个数字*/
public class MinSubArray {
    public int minSubArray(List<Integer> nums) {
        int res=nums.get(0);
        int dp=0;
        for(Integer num:nums){
            if(dp<0){
                dp+=num;
            }else{
                dp=num;
            }
            res=Math.min(dp,res);
        }
        return res;
    }
}
