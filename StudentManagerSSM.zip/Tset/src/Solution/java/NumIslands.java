import java.util.Arrays;

/*给一个 01 矩阵，求不同的岛屿的个数。
        0 代表海，1 代表岛，如果两个 1 相邻，那么这两个 1 属于同一个岛。我们只考虑上下左右为相邻。
        样例
        样例 1：
        输入：
        [
        [1,1,0,0,0],
        [0,1,0,0,1],
        [0,0,0,1,1],
        [0,0,0,0,0],
        [0,0,0,0,1]
        ]
        输出：
        3
        样例 2：
        输入：
        [
        [1,1]
        ]
        输出：
        1*/
public class NumIslands {
    public int numIslands(boolean[][] grid) {
       /* int m=grid.length;
        if(m==0) {
            return 0;
        }
        int n=grid[0].length;
        if(n==0) {
            return 0;
        }
        int res=0;
        for(int i=0;i<m;i++) {
            for(int j=0;j<n;j++) {
                if(grid[i][j]) {
                    resetRound(grid,i,j);
                    res++;
                }
            }
        }
        return res;*/
        int n=grid[0].length;
        int m=grid.length;
        int res=0;
        if(n==0||m==0){
            return 0;
        }
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                if(grid[i][j]){
                    resetRound(grid,i,j);
                    res++;
                }
            }
        }
        return res;
    }
    void resetRound(boolean[][] v,int i,int j) {
        /*int m=v.length;
        int n=v[0].length;
        //这里一定是要出边界而不能是在边界上
        if(i<0||i>=m||j<0||j>=n) {
            return;
        }
        if(v[i][j]) {
            v[i][j]=false;
            resetRound(v,i-1,j);
            resetRound(v,i+1,j);
            resetRound(v,i,j-1);
            resetRound(v,i,j+1);
        }*/
        int m=v[0].length;
        int n=v.length;
        if(i<0||i>=m||j<0||j>=n){
            return;
        }
        if(v[i][j]){
            v[i][j]=false;
            resetRound(v,i+1,j);
            resetRound(v,i-1,j);
            resetRound(v,i,j+1);
            resetRound(v,i,j-1);
        }
    }

    public static void main(String[] args) {
        boolean[][] grid=new boolean[][]{new boolean[]{true,true,false,false,false},
                                         new boolean[]{false,true,false,false,true},
                                         new boolean[]{false,false,false,true,true},
                                         new boolean[]{false,false,false,false,false},
                                         new boolean[]{false,false,false,false,true}};
        NumIslands numIslands=new NumIslands();
        System.out.println(numIslands.numIslands(grid));
    }
}
