/*给定一个n * m 的矩阵 carrot, carrot[i][j] 表示(i, j) 坐标上的胡萝卜数量。
        从矩阵的中心点出发，每一次移动都朝着四个方向中胡萝卜数量最多的方向移动，保证移动方向唯一。
        返回你可以得到的胡萝卜数量。
        样例
        示例 1:
        输入:
        carrot =
        [[5, 7, 6, 3],
        [2,  4, 8, 12],
        [3, 5, 10, 7],
        [4, 16, 4, 17]]
        输出: 83
        解释：起点坐标是(1, 1), 移动路线是：4 -> 8 -> 12 -> 7 -> 17 -> 4 -> 16 -> 5 -> 10
        示例 2:
        输入:
        carrot =
        [[5, 3, 7, 1, 7],
        [4, 6, 5, 2, 8],
        [2, 1, 1, 4, 6]]
        输出: 30
        解释：起始点是 (1, 2), 移动路线是： 5 -> 7 -> 3 -> 6 -> 4 -> 5
        注意事项
        n 和 m 的长度范围是: [1, 300]
        carrot[i][j] 的取值范围是: [1, 20000]
        中心点是向下取整, 例如n = 4, m = 4, start point 是 (1, 1)
        如果格子四周都没有胡萝卜则停止移动*/
public class PickCarrots {
    public int pickCarrots(int[][] carrot) {
        // write your code here

        // 上左下右的相对坐标
        final int[][] ps = new int[][]{new int[]{-1, 0}, new int[]{0, -1}, new int[]{1, 0}, new int[]{0, 1}};

        // 最大行
        int n = carrot.length;
        // 最大列
        int m = carrot[0].length;

        // 结果
        int ret = 0;
        for (int i = (n - 1) / 2, j = (m - 1) / 2; ; ) {
            // 增加数量
            ret += carrot[i][j];
            // 将数量取反，标记已经拔掉萝卜
            carrot[i][j] = -carrot[i][j];

            int c    = -1;
            int tmpI = -1;
            int tmpJ = -1;

            // 循环四个方向
            for (int[] p : ps) {
                int tI = i + p[0];
                int tJ = j + p[1];
                if (tI >= 0
                        && tI < n
                        && tJ >= 0
                        && tJ < m
                        && carrot[tI][tJ] > c) {
                    c = carrot[tI][tJ];
                    tmpI = tI;
                    tmpJ = tJ;
                }
            }

            if (c > 0) {
                i = tmpI;
            } else {
                j = tmpJ;
                break;
            }
        }

        return ret;
    }

    public static void main(String[] args) {
        int[][] nums={{2,9,8,4},{3,6,1,5},{9,3,6,8},{7,4,2,8}};
        PickCarrots pickCarrots=new PickCarrots();
        pickCarrots.pickCarrots(nums);
    }
}
