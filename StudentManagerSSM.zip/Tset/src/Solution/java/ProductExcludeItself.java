import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/*给定一个整数数组A。
        定义B[i] = A[0] * ... * A[i-1] * A[i+1] * ... * A[n-1]， 计算B的时候请不要使用除法。请输出B。
        样例
        样例 1
        输入: A = [1, 2, 3]
        输出: [6, 3, 2]
        解析：B[0] = A[1] * A[2] = 6; B[1] = A[0] * A[2] = 3; B[2] = A[0] * A[1] = 2
        样例 2
        输入: A = [2, 4, 6]
        输出: [24, 12, 8]*/
public class ProductExcludeItself {
    public List<Long> productExcludeItself(List<Integer> nums) {
        /*List list=new ArrayList();
        int i=nums.size();
        long c=1;
        for(int m=0;m<i;m++){
            int as=0;
            as=nums.get(m);
            nums.set(m,1);
            for(int n=0;n<nums.size();n++){
                c = ((int)nums.get(n))*c;
            }
            list.add(m,c);
            nums.set(m,as);
            c=1;
        }
        return list;*/

        //更优
        Long temp = Long.parseLong("1");
        List<Long> left = new ArrayList<Long>();
        for (int i = 0; i < nums.size(); i++) {
            left.add(temp);
            temp *= nums.get(i);
        }
        System.out.println(left);
        temp = Long.parseLong("1");
        for (int i = nums.size()-1; i >=0; i--) {
            left.set(i, left.get(i) * temp);
            System.out.println(left);
            temp *= nums.get(i);
        }
        return left;
    }

    public static void main(String[] args) {
        List<Integer> nums=new ArrayList();
        nums.add(2);
        nums.add(4);
        nums.add(6);
        ProductExcludeItself productExcludeItself=new ProductExcludeItself();
        System.out.println(productExcludeItself.productExcludeItself(nums));
    }
}
