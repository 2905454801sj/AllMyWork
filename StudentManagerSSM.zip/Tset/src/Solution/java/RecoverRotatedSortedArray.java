import java.util.*;

/*给定一个旋转排序数组，在原地恢复其排序。（升序）
        样例
        Example1:
        [4, 5, 1, 2, 3] -> [1, 2, 3, 4, 5]
        Example2:
        [6,8,9,1,2] -> [1,2,6,8,9]
        挑战
        使用O(1)的额外空间和O(n)时间复杂度
        说明
        什么是旋转数组？
        比如，原始数组为[1,2,3,4], 则其旋转数组可以是[1,2,3,4], [2,3,4,1], [3,4,1,2], [4,1,2,3]*/
public class RecoverRotatedSortedArray {
    public void recoverRotatedSortedArray(List<Integer> nums) {
        for(int index = 0; index < nums.size() - 1; index++){
            if(nums.get(index) > nums.get(index + 1)){
                reverse(nums, 0, index);
                reverse(nums, index+1, nums.size()-1);
                reverse(nums, 0, nums.size()-1);
            }
        }
    }

    public void reverse (List<Integer> nums, int start, int end){
        for(int i = start, j = end; i < j; i++, j--){
            int temp = nums.get(i);
            nums.set(i, nums.get(j));
            nums.set(j, temp);
        }
    }

    public static void main(String[] args) {
        List<Integer> nums=new ArrayList<>();
        for(int i=5;i<8;i++){
            nums.add(i);
        }
        nums.add(3);
        nums.add(4);
        //System.out.println(nums.toString());
        RecoverRotatedSortedArray recoverRotatedSortedArray=new RecoverRotatedSortedArray();
        recoverRotatedSortedArray.recoverRotatedSortedArray(nums);
        System.out.println(nums.toString());
    }
}
