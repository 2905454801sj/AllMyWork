import java.util.Stack;

/*翻转一个链表
        样例
        样例 1:
        输入: 1->2->3->null
        输出: 3->2->1->null
        样例 2:
        输入: 1->2->3->4->null
        输出: 4->3->2->1->null
        挑战
        在原地一次翻转完成*/
public class Reverse {
    public static class ListNode {
        int val;
        ListNode next;
        ListNode(int x) {
            val = x;
            next = null;
        }
    }
    public ListNode reverse(ListNode head) {
        if(head == null || head.next == null){
            return head;
        }

        ListNode reNode = reverse(head.next);
        head.next.next = head;
        head.next = null;
        return reNode;
    }

    public static void main(String[] args) {
        ListNode head=new ListNode(2);
        Reverse re=new Reverse();
        re.reverse(head);
    }
}
