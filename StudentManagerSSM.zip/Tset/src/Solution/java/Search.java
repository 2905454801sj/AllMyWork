/*
Suppose a sorted array is rotated at some pivot unknown to you beforehand.
        (i.e., 0 1 2 4 5 6 7 might become 4 5 6 7 0 1 2).
        You are given a target value to search. If found in the array return its index, otherwise return -1.
        You may assume no duplicate exists in the array.
        样例
        Example 1:
        Input: [4, 5, 1, 2, 3] and target=1,
        Output: 2.
        Example 2:
        Input: [4, 5, 1, 2, 3] and target=0,
        Output: -1.
        挑战
        O(logN) 时间限制
*/

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class Search {
    public int search(int[] A, int target) {
        HashMap<Integer,Integer> hashMap=new HashMap<>();
        for(int i=0;i<A.length;i++){
            hashMap.put(A[i],i);
        }
        if(hashMap.containsKey(target)) {
            return hashMap.get(target);
        }else{
            return -1;
        }
    }

    public static void main(String[] args) {
        int[] A=new int[]{4,5,1,2,3};
        Search search=new Search();
        System.out.println(search.search(A,6));
    }
}
