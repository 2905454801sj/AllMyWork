/*对于一个给定的 source 字符串和一个 target 字符串，你应该在 source 字符串中找出 target 字符串出现的第一个位置(从0开始)。如果不存在，则返回 -1。

        样例
        样例 1:

        输入: source = "source" ， target = "target"
        输出:-1
        样例解释: 如果source里没有包含target的内容，返回-1
        样例 2:

        输入: source = "abcdabcdefg" ，target = "bcd"
        输出: 1
        样例解释: 如果source里包含target的内容，返回target在source里第一次出现的位置
        挑战
        O(n2)的算法是可以接受的。如果你能用O(n)的算法做出来那更加好。（提示：KMP）*/
public class StrStr {
    public int[] next(String target){
        int k=0;
        int[] a=new int[target.length()];
        a[0]=0;
        for(int i=1,j=0;i<target.length();i++){
            while (j>0&&target.charAt(i)!=target.charAt(j)){
                j=a[j-1];
            }
            if(target.charAt(i)==target.charAt(j)){
                j++;
            }
            a[i]=j;
        }
        return a;
    }
    public int strStr(String source, String target) {
        if(source.equals(target)&&target.length()!=0){
            return 0;
        }
        if(target.length()==0){
            return 0;
        }
        if(source.length()==0){
            return -1;
        }
        int[] next=next(target);;
        for (int i=0,j=0;i<source.length();i++){
            while(j>0&&source.charAt(i)!=target.charAt(j)){
                j=next[j-1];
            }
            if(source.charAt(i)==target.charAt(j)){
                j++;
            }
            if(j==target.length()){
                return i-j+1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        String a="abcdefgabcedabcd";
        String b="abcd";
        StrStr strStr=new StrStr();
        int n=strStr.strStr(a,b);
        System.out.println(n);
        System.out.println(a.equals(b));;
    }
}
