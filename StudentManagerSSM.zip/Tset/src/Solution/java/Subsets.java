import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/*给定一个含不同整数的集合，返回其所有的子集。
        样例
        Example 1:
        Input: [0]
        Output:
        [[],[0]]
        Example 2:
        Input: [1,2,3]
        Output:
        [
        [3],
        [1],
        [2],
        [1,2,3],
        [1,3],
        [2,3],
        [1,2],
        []
        ]
        挑战
        你可以同时用递归与非递归的方式解决么？
        注意事项
        子集中的元素排列必须是非降序的，解集必须不包含重复的子集。*/
public class Subsets {
    public List<List<Integer>> subsets(int[] nums) {
        //非递归
        /*ArrayList<List<Integer>> res= new ArrayList<>();
        if(nums==null ){
            return res;
        }
        res.add(new ArrayList<>());
        Arrays.sort(nums);
        for(int i=0;i<nums.length;i++){
            for(int j=0;j<Math.pow(2,i);j++){//每一层的个数都是2的n次方
                ArrayList<Integer> temp2=new ArrayList<Integer>(res.get(j));
                temp2.add(temp2.size(),nums[i]);
                System.out.println("第"+i+"次"+temp2.size()+"   "+nums[i]);
                System.out.println(temp2);
                res.add(temp2);//加入一个数，放进去
            }
        }
        return res;*/
        /*ArrayList<List<Integer>> res=new ArrayList<>();
        if(nums==null){
            return res;
        }
        List<Integer> list=new ArrayList<>();
        res.add(list);
        Arrays.sort(nums);
        for(int i=0;i<nums.length;i++){
            for(int j=0;j<Math.pow(2,i);j++){
                ArrayList<Integer> arrayList=new ArrayList<>(res.get(j));
                arrayList.add(arrayList.size(),nums[i]);
                res.add(arrayList);
            }
        }
        return res;*/
        //递归
        List<List<Integer>> result = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
        if (nums == null) {
            return result;
        }
        if (nums.length == 0) {
            result.add(list);
            return result;
        }
        Arrays.sort(nums);
        int startIndex = 0;
        helper2(list,nums,startIndex,result);
        return result;
    }
    //递归方法
    private void helper2(List<Integer> subset, int[] nums, int startIndex, List<List<Integer>> results) {
        results.add(new ArrayList<Integer>(subset));
        for (int i = startIndex; i < nums.length; i++) {
            subset.add(nums[i]);
            System.out.println("+:"+subset.toString());
            helper2(subset, nums, i + 1, results);
            subset.remove(subset.size() - 1);
            System.out.println("-:"+subset.toString());
        }
        //return;
    }
    public static void main(String[] args) {
        int[] nums=new int[]{1,2,3};
        Subsets subsets=new Subsets();
        System.out.println(subsets.subsets(nums));
    }
}
