import java.util.*;

/*给出一个有n个整数的数组S，在S中找到三个整数a, b, c，找到所有使得a + b + c = 0的三元组。
        样例
        例1:
        输入:[2,7,11,15]
        输出:[]
        例2:
        输入:[-1,0,1,2,-1,-4]
        输出:[[-1, 0, 1],[-1, -1, 2]]
        注意事项
        在三元组(a, b, c)，要求a <= b <= c。
        结果不能包含重复的三元组。*/
public class ThreeSum {
    public List<List<Integer>> threeSum(int[] numbers) {
        List<List<Integer>> list=new ArrayList<>();
        if(numbers==null||numbers.length<3){
            return list;
        }
        Arrays.sort(numbers);
        for(int i=0;i<numbers.length-2;i++){
            if(i>0&&numbers[i]==numbers[i-1]){
                continue;
            }
            int as=-numbers[i];
            int right=numbers.length-1;
            int left=i+1;
            res(numbers,right,left,as,list);
        }
        return list;
    }
    private void res(int[] numbers,int right,int left,int as,List<List<Integer>> list){
        while(left<right){
        }
        if(numbers[left]+numbers[right]==as){
            List<Integer> list1=new ArrayList<>();
            list1.add(-as);
            list1.add(numbers[left] );
            list1.add(numbers[right]);
            list.add(list1);
            left++;
            right--;
            while(left<right&&numbers[left]==numbers[left-1]){
                left++;
            }
            while(left<right&&numbers[right]==numbers[right+1]){
                right--;
            }
        }else if(numbers[left]+numbers[right]<as){
            left++;
        }else {
            right--;
        }
    }
    public static void main(String[] args) {
        ThreeSum threeSum=new ThreeSum();
        int[] numbers={-1,-3,1,2,-1,-4,2};
        System.out.println(threeSum.threeSum(numbers));
    }
}
