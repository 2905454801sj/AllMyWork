import java.util.Arrays;
import java.util.HashMap;

/*给一个整数数组，找到两个数使得他们的和等于一个给定的数 target。
        你需要实现的函数twoSum需要返回这两个数的下标, 并且第一个下标小于第二个下标。注意这里下标的范围是 0 到 n-1。
        样例
        样例1:
        给出 numbers = [2, 7, 11, 15], target = 9, 返回 [0, 1].
        样例2:
        给出 numbers = [15, 2, 7, 11], target = 9, 返回 [1, 2].
        挑战
        给自己加点挑战
        O(n)O(n) 空间复杂度，O(nlogn)O(nlogn) 时间复杂度，
        O(n)O(n) 空间复杂度，O(n)O(n) 时间复杂度，
        注意事项
        你可以假设只有一组答案。*/
public class TwoSum {
    public int[] twoSum(int[] numbers, int target) {
        /*int left=0;
        int right=numbers.length-1;
        while(left<right){
            for(left=0;left<numbers.length;left++) {
                while(numbers[left] + numbers[right] != target &&left<right) {
                    right--;
                }
                if(numbers[left] + numbers[right] == target){
                    return new int[]{left,right};
                }
                right=numbers.length-1;
            }
        }
        return null;*/
        //更优方案
       /* HashMap<Integer,Integer> maps=new HashMap<Integer,Integer>();
        for(int i=0;i<numbers.length;i++)
        {
            maps.put(numbers[i],i);
        }
        int tmp=0;
        int result[]=new int[2];
        for(int i=0;i<numbers.length;i++)
        {
            tmp=target-numbers[i];
            if(maps.get(tmp)!=null)
            {
                result[0]=i;
                result[1]=maps.get(tmp);
                return result;
            }
        }
        return result;*/
        HashMap<Integer,Integer> hashMap=new HashMap<>();
        for(int i=0;i<numbers.length;i++){
            hashMap.put(numbers[i],i);
        }
        for(int i=0;i<numbers.length;i++){
            int temp=target-numbers[i];
            if(hashMap.get(temp)!=null){
                return new int[]{i,hashMap.get(temp)};
            }
        }
        return null;
    }

    public static void main(String[] args) {
        int[] numbers=new int[]{1,0,-1};
        TwoSum twoSum=new TwoSum();
        System.out.println(Arrays.toString(twoSum.twoSum(numbers,-1)));
    }
}
