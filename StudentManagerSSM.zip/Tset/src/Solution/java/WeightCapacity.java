import java.util.*;

public class WeightCapacity {
    /*
    奥利第一次来到健身房，她正在计算她能举起的最大重量。杠铃所能
    承受的最大重量为maxCapacity，健身房里有n个杠铃片，第 i 个
    杠铃片的重量为 weights[i]。奥利现在需要选一些杠铃片加到杠铃
    上，使得杠铃的重量最大，但是所选的杠铃片重量总和又不能超过 maxCapacity
    ，请计算杠铃的最大重量是多少。
    比如，给定杠铃片的重量为 weights = [1, 3, 5]， 而杠铃的最
    大承重为 maxCapacity = 7，那么应该选择重量为 1 和 5 的
    杠铃片，(1 + 5 = 6)，所以最终的答案是 6。
    样例 1
    输入：
    [1,3,5,9]
    8
    输出：
    8
     */
    public int weightCapacity(int[] weights, int maxCapacity) {
        List list=Arrays.asList(weights);
        Collections.sort(list);
        for(int i=0;i<list.size();i++){
            if(list.get(i)>maxCapacity){
                list.remove(i);
            }
            if((int)list.get(i)==maxCapacity){
                return maxCapacity;
            }
        }
        int max=0;
        int temp=0;
        int index1=0;
        int index2=0;
        return DG(list,max,temp,index1,index2);
    }
    public int DG(List list,int max,int temp,int index1,int index2){
        temp=(int)list.get(index1)+(int)list.get(list.size()-1-index2);
        if(temp<max){
            index1++;
            DG(list,max,temp,index1,index2);
        }
        if(temp>max){
            index2++;
            DG(list,max,temp,index1,index2);
        }
        return temp;
    }

    public static void main(String[] args) {
        int[] weights={1,3,5};
        WeightCapacity weightCapacity=new WeightCapacity();
        Optional.of(weightCapacity.weightCapacity(weights,7)).ifPresent(System.out::println);
    }
}
