/*有一些原木，现在想把这些木头切割成一些长度相同的小段木头，需要得到的小段的数目至少为 k。
当然，我们希望得到的小段越长越好，你需要计算能够得到的小段木头的最大长度。
        样例
        Example 1
        Input:
        L = [232, 124, 456]
        k = 7
        Output: 114
        Explanation: We can cut it into 7 pieces if any piece is 114cm long, however we can't cut it into 7 pieces if any piece is 115cm long.
        Example 2
        Input:
        L = [1, 2, 3]
        k = 7
        Output: 0
        Explanation: It is obvious we can't make it.
        挑战
        O(n log Len), Len为 n 段原木中最大的长度
        注意事项
        木头长度的单位是厘米。原木的长度都是正整数，我们要求切割得到的小段木头的长度也要求是整数。无法切出要求至少 k 段的,则返回 0 即可。*/
public class WoodCut {
    public int woodCut(int[] L, int k) {
        /*long start = 1;
        long end = 0;
        for (int i = 0; i < L.length; i++)
        {
            end = Math.max(end, L[i]);
        }
        while (start <= end)
        {
            long mid = (end + start) / 2;
            int count = 0;
            for (int i = 0; i < L.length; i++)
            {
                count += L[i] / mid;
            }
            //start = count >= k ? ++mid : start;
            if(count>=k){
                start=++mid;
            }else{
                start=start;
            }
            //end = count < k ? --mid : end;
            if(count<k){
                end=--mid;
            }else {
                end=end;
            }
        }
        return (int)end;*/
        long start=1;
        long end=0;
        for(int i=0;i<L.length;i++){
            end=Math.max(end,L[i]);
        }
        while(start<=end){
            long mid=(start+end)/2;
            int count=0;
            for(int i=0;i<L.length;i++){
                count+=L[i]/mid;
            }
            /*if(count>=k){
                start=++mid;
            }else{
                start=start;
            }*/
            start=count>=k?++mid:start;
            /*if(count<k){
                end=--mid;
            }else {
                end=end;
            }*/
            end=count<k?--mid:end;
        }
        return (int)end;
    }

    public static void main(String[] args) {
        int[] l=new int[]{232, 124, 456};
        WoodCut woodCut=new WoodCut();
        System.out.println(woodCut.woodCut(l,7));
    }
}
