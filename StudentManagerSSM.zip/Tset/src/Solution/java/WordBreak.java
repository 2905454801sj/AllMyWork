import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*      给定字符串 s 和单词字典 dict，确定 s 是否可以分成一个或多个以空格分隔的子串，并且这些子串都在字典中存在。
        因为我们已经使用了更强大的数据，所以普通的DFS方法已经无法通过此题。
        样例
        样例 1:
        输入:
        "lintcode"
        ["lint", "code"]
        输出:
        true
        样例 2:
        输入:
        "a"
        ["a"]
        输出:
        true
        注意事项
        s.length <= 1e5
        dict.size <= 1e5*/
public class WordBreak {
    private int getMaxLength(Set<String> dict) {
        int maxLength = 0;
        for (String word : dict) {
            maxLength = Math.max(maxLength, word.length());
        }
        return maxLength;
    }
    public boolean wordBreak(String s, Set<String> wordSet) {
        if (s == null || s.length() == 0) {
            return true;
        }
        int maxLength = getMaxLength(wordSet);
        boolean[] canSegment = new boolean[s.length() + 1];
        // 初值，使canSegment[1]对应第一个字母，方便阅读
        canSegment[0] = true;
        for (int i = 1; i <= s.length(); i++) {
            canSegment[i] = false;
            for (int lastWordLength = 1;
                 lastWordLength <= maxLength && lastWordLength <= i;
                 lastWordLength++) {
                // 找到去掉某个长为lastWordLength的单词后，从0到i - lastWordLength位置的字符串是满足切分条件的
                if (!canSegment[i - lastWordLength]) {
                    continue;
                }
                // 判断去掉的单词是不是在字典中
                /* substring(int beginIndex, int endIndex)
                 * 从beginIndex开始取，到endIndex结束
                 * 从0开始数，其中不包括endIndex位置的字符
                 */
                String word = s.substring(i - lastWordLength, i);
                if (wordSet.contains(word)) {
                    canSegment[i] = true;
                    break;
                }
            }
        }

        return canSegment[s.length()];
    }

    public static void main(String[] args) {
        String s="a";
        Set<String> wordSet=new HashSet<>();
        //wordSet.add("b");
        wordSet.add("a");
        WordBreak wordBreak=new WordBreak();
        System.out.println(wordBreak.wordBreak(s,wordSet));
    }
}
