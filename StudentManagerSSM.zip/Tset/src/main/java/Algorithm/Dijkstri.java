package Algorithm;

import java.util.Arrays;

class DGraph{
    private char[] vertex;//顶点
    private int[][] matrix;//邻接矩阵
    private VisitedV visitedV;
    public DGraph(char[] vertex,int[][] matrix){
        this.vertex=vertex;
        this.matrix=matrix;
    }
    public void show(){
        for(int[] link:matrix){
            System.out.println(Arrays.toString(link));
        }
    }
    public void djs(int index){
        visitedV = new VisitedV(vertex.length, index);
        update(index);//更新index顶点到周围顶点的距离和前驱顶点
        for(int j=1;j<vertex.length;j++){
            index=visitedV.updateArr();//选择并返回新的访问顶点
            update(index);//更新index顶点到周围顶点的距离和前驱顶点
        }
    }
    //更新index下标顶点到周围顶点的距离和周围顶点的前驱顶点
    private void update(int index){
        int len=0;
        for(int j=0;j<matrix[index].length;j++){
            len=visitedV.getDis(index)+matrix[index][j];
            //j未被访问并且len小于出发节点到j顶点的距离，需要更新
            if(!visitedV.in(j)&&len<visitedV.getDis(j)){
                visitedV.updatePre(j,index);
                visitedV.updateDis(j,len);
            }
        }
    }
    public void showDjs(){
        visitedV.show();
    }
}
class VisitedV{
    public int[] alarr;//记录已访问过的点，已访问为1，未访问为0
    public int[] prec;//每个下标的值为前一个顶点的下标，动态更新
    public int[] dis;//记录出发顶点到其他所有顶点的距离
    public VisitedV(int len,int index){
        this.alarr=new int[len];
        this.prec=new int[len];
        this.dis=new int[len];
        //初始化dis
        Arrays.fill(dis,8888);
        this.alarr[index]=1;//设置出发顶点被访问过
        this.dis[index]=0;//设置出发顶点的访问距离为0
    }
    public boolean in(int index){
        return alarr[index]==1;
    }

    /**
     * 更新出发顶点到index顶点的距离
     * @param index
     * @param len
     */
    public void updateDis(int index,int len){
        dis[index]=len;
    }

    /**
     * 更新pre这个顶点到前驱顶点为index顶点
     * @param pre
     * @param index
     */
    public void updatePre(int pre,int index){
        prec[pre]=index;
    }

    /**
     * 返回出发顶点到index顶点的距离
     * @param index
     */
    public int getDis(int index){
        return dis[index];
    }

    /**
     * 继续选择并返回新的访问顶点
     */
    public int updateArr(){
        int min=8888,index =0;
        for(int i=0;i<alarr.length;i++){
            if(alarr[i]==0&&dis[i]<min){
                min=dis[i];
                index=i;
            }
        }
        alarr[index]=1;
        return index;
    }
    public void show(){
        for(int i:alarr){
            System.out.printf(i+" ");
        }
        System.out.println();
        for(int i:prec){
            System.out.printf(i+" ");
        }
        System.out.println();
        for(int i:dis){
            System.out.printf(i+" ");
        }
        System.out.println();
        char[] vertex={'A','B','C','D','E','F','G'};
        int count=0;
        for(int i:dis){
            if(i!=8888){
                System.out.print(vertex[count]+"("+i+")");
            }else{
                System.out.print("N");
            }
            count++;
        }
    }
}
public class Dijkstri {
    public static void main(String[] args) {
        char[] vertex={'A','B','C','D','E','F','G'};
        int[][] matrix=new int[vertex.length][vertex.length];
        final int N=8888;
        matrix[0]=new int[]{N,2,3,4,N,7,N};
        matrix[1]=new int[]{1,N,3,7,9,N,2};
        matrix[2]=new int[]{2,N,N,7,6,9,N};
        matrix[3]=new int[]{5,2,N,N,N,7,6};
        matrix[4]=new int[]{N,1,3,4,N,8,9};
        matrix[5]=new int[]{5,N,7,N,6,N,9};
        matrix[6]=new int[]{N,N,5,9,N,7,N};
        DGraph dGraph=new DGraph(vertex,matrix);
        dGraph.show();
        dGraph.djs(6);
        dGraph.showDjs();
    }
}
