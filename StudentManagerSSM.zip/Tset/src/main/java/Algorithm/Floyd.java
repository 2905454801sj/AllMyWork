package Algorithm;

import java.util.Arrays;

class GraphF{
    private char[] vertex;//顶点数组
    private int[][] dis;//保存从各个顶点出发到其他顶点的距离
    private int[][] pre;//到达目标节点的先驱顶点
    public GraphF(int len,int[][] matirx,char[] vertex){
        this.vertex=vertex;
        this.dis=matirx;
        this.pre=new int[len][len];
        for(int i=0;i<len;i++){
            Arrays.fill(pre[i],i);
        }
    }
    public void show(){
        char[] vertex={'A','B','C','D','E','F','G'};
        for(int k=0;k<dis.length;k++){
            for(int j=0;j<dis.length;j++){
                System.out.print(vertex[pre[k][j]]+" ");
            }
            System.out.println();
            for(int i=0;i<dis.length;i++){
                System.out.print("("+vertex[k]+"到"+vertex[i]+"的最短路径为"+dis[k][i]+")  ");
            }
            System.out.println();
        }
    }
    public void floyd(){
        int len=0;
        //从中间顶点遍历，k 就是中间顶点的下标
        for(int k=0;k<dis.length;k++){
            //从i顶点出发
            for(int i=0;i<dis.length;i++){
                //到达j顶点
                for(int j=0;j<dis.length;j++){
                    len=dis[i][k]+dis[k][j];
                    if(len<dis[i][j]){
                        dis[i][j]=len;//更新距离
                        pre[i][k]=pre[k][j];
                    }
                }
            }
        }
    }
}
public class Floyd {

    public static void main(String[] args) {
        char[] vertex={'A','B','C','D','E','F','G'};
        int[][] matrix=new int[vertex.length][vertex.length];
        final int N=8888;
        matrix[0]=new int[]{0,2,N,4,N,7,N};
        matrix[1]=new int[]{1,0,3,N,9,N,2};
        matrix[2]=new int[]{2,N,0,7,6,9,N};
        matrix[3]=new int[]{5,2,N,0,N,7,6};
        matrix[4]=new int[]{N,1,3,4,0,N,9};
        matrix[5]=new int[]{5,N,7,N,6,0,9};
        matrix[6]=new int[]{N,N,5,9,N,7,0};
        GraphF graphF = new GraphF(vertex.length, matrix, vertex);
        graphF.show();
        System.out.println("Floyd:");
        graphF.floyd();
        graphF.show();
    }
}
