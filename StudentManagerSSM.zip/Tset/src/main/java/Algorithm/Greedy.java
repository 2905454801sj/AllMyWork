package Algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Greedy {
    public static void main(String[] args) {
        HashMap<String, HashSet<String>> stringHashSetHashMap = new HashMap<String,HashSet<String>>();
        //将电台放入hsahmap
        HashSet<String> hashSet1=new HashSet<String>();
        hashSet1.add("1");
        hashSet1.add("2");
        hashSet1.add("3");
        HashSet<String> hashSet2=new HashSet<String>();
        hashSet2.add("1");
        hashSet2.add("8");
        hashSet2.add("5");
        HashSet<String> hashSet3=new HashSet<String>();
        hashSet3.add("4");
        hashSet3.add("6");
        HashSet<String> hashSet4=new HashSet<String>();
        hashSet4.add("7");
        hashSet4.add("9");
        HashSet<String> hashSet5=new HashSet<String>();
        hashSet5.add("8");
        hashSet5.add("9");
        stringHashSetHashMap.put("k1",hashSet1);
        stringHashSetHashMap.put("k2",hashSet2);
        stringHashSetHashMap.put("k3",hashSet3);
        stringHashSetHashMap.put("k4",hashSet4);
        stringHashSetHashMap.put("k5",hashSet5);
        HashSet<String> allset = new HashSet<String>();
        allset.add("1");
        allset.add("2");
        allset.add("3");
        allset.add("4");
        allset.add("5");
        allset.add("6");
        allset.add("7");
        allset.add("8");
        allset.add("9");
        //存放选择的电台
        ArrayList<String> select = new ArrayList<String>();
        //定义临时集合，在遍历过程中，存放覆盖和未覆盖地区的交集
        HashSet<String> tempset = new HashSet<String>();
        //定义一个maxkey，保存在一次遍历过程中能够覆盖最多未覆盖的地区的电台的key
        String maxkey=null;
        while(allset.size()!=0){
            maxkey=null;
            for(String key:stringHashSetHashMap.keySet()){
                tempset.clear();
                HashSet<String> areas=stringHashSetHashMap.get(key);
                tempset.addAll(areas);
                //求tempset和allareas的交集
                tempset.retainAll(allset);
                //若当前集合包含的未覆盖的地区数量大于maxkey指向的集合地区多，则重置maxkey'
                if(tempset.size()>0&&(maxkey==null||tempset.size()>stringHashSetHashMap.get(maxkey).size())){
                    maxkey=key;
                }
            }
            if(maxkey!=null){
                   select.add(maxkey);
                   allset.removeAll(stringHashSetHashMap.get(maxkey));
            }
        }
        System.out.println(select);
    }
}
