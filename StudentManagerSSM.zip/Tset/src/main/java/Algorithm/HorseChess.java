package Algorithm;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;

public class HorseChess {
    private static int x;//棋盘列
            private static int y;//棋盘行
            private static boolean visited[];//表示某个位置是否被访问过
            private static boolean finished;//表示成功

            /**
             *完成骑士周期的问题的算法
             * @param chessboard 棋盘
             * @param row 行，从0开始
             * @param col 列，从0开始
             * @param step 步骤是第几步
             */
            public static void travelChess(int[][] chessboard,int row,int col,int step){
        chessboard[row][col]=step;
        visited[row*x+col]=true;//表示第几个已被访问
        //获取当前位置可以走的下一个位置的集合
        ArrayList<Point> next = next(new Point(col, row));
        //对next排序
        sort(next);
        //遍历next
        while(!next.isEmpty()){
            Point remove = next.remove(0);
            if(!visited[remove.y*x+remove.x]){//说明未访问
                travelChess(chessboard, remove.y, remove.x, step+1);
            }
        }
        //说明未完成任务
        if(step<x*y&&!finished){
            chessboard[row][col]=0;
            visited[row*x+col]=false;
        }else{
            finished=true;
        }
    }
    public static ArrayList<Point> next(Point cur){
        ArrayList<Point> points = new ArrayList<>();
        Point p=new Point();
        if((p.x=cur.x-2)>=0&&(p.y=cur.y-1)>=0){
            points.add(new Point((p)));
        }
        if((p.x=cur.x-1)>=0&&(p.y=cur.y-2)>=0){
            points.add(new Point((p)));
        }
        if((p.x=cur.x+1)<x&&(p.y=cur.y-2)>=0){
            points.add(new Point((p)));
        }
        if((p.x=cur.x+2)<x&&(p.y=cur.y-1)>=0){
            points.add(new Point((p)));
        }
        if((p.x=cur.x+2)<x&&(p.y=cur.y+1)<y){
            points.add(new Point((p)));
        }
        if((p.x=cur.x+1)<x&&(p.y=cur.y+2)<y){
            points.add(new Point((p)));
        }
        if((p.x=cur.x-1)>=0&&(p.y=cur.y+2)<y){
            points.add(new Point((p)));
        }
        if((p.x=cur.x-2)>=0&&(p.y=cur.y+1)<y){
            points.add(new Point((p)));
        }
        return points;
    }
    //根据当前这一步的所有的下一步的选择位置，进行非递减排序，减少回溯
    public static void sort(ArrayList<Point> ps){
        ps.sort(new Comparator<Point>() {
            public int compare(Point o1, Point o2) {
                int count1=next(o1).size();
                int count2=next(o2).size();
                if(count1<count2){
                    return -1;
                }else if(count1==count2){
                    return 0;
                }else{
                    return 1;
                }
            }
        });
    }
    public static void main(String[] args) {
        x=8;
        y=8;
        int row=1;
        int col=1;
        int[][] chessboard=new int[x][y];
        visited=new boolean[x*y];
        long l0= System.currentTimeMillis();
        travelChess(chessboard,row-1,col-1,1);
        long l1 = System.currentTimeMillis();
        System.out.println("耗时"+(l1-l0)+"毫秒");
        for(int[] rows:chessboard){
            for(int steps:rows){
                System.out.print(steps+"\t");
            }
            System.out.println();
        }
    }
}
