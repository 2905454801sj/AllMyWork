package Algorithm;

import java.util.Arrays;

public class KMP {
    //获得一个字符串的部分匹配值
    public static int[] Next(String dest){
        int[] a=new int[dest.length()];
        a[0]=0;//如果dest长度为1，部分匹配值就是0
        for(int i=1,j=0;i<dest.length();i++){
            //dest.charAt(i)!=dest.charAt(j)时，我们需要从a[j-1]获取新的j,直到我们发现有dest.charAt(i)==dest.charAt(j)成立
            while(j>0&&dest.charAt(i)!=dest.charAt(j)){
                j=a[j-1];
            }
            //dest.charAt(i)=dest.charAt(j)时，部分匹配值就是+1
            if(dest.charAt(i)==dest.charAt(j)){
                j++;
            }
            a[i]=j;
        }
        return a;
    }
    //写出KMP搜索算法
    public static int search(String s1,String s2,int[] next){
        //遍历
        //KMP核心算法点
        for(int i=0,j=0;i<s1.length();i++){
            while(j>0&&s1.charAt(i)!=s2.charAt(j)){
                j=next[j-1];
            }
            if(s1.charAt(i)==s2.charAt(j)){
                j++;
            }
            if(j==s2.length()){
                return i-j+1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        String s1="asa sddas sdasasad asasad";
        String s2="asasad";

        int[] next=Next(s2);
        System.out.println(Arrays.toString(next));
        int index=search(s1,s2,next);
        System.out.println(index);
    }
}
