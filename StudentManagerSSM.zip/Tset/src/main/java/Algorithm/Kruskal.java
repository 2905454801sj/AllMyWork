package Algorithm;

import java.util.Arrays;

class EData{//对象实例即一条边
    char start;
    char end;
    int weight;
    public EData(char start,char end,int weight){
        this.start=start;
        this.end=end;
        this.weight=weight;
    }
    @Override
    public String toString() {
        return "EData{" +
                "start=" + start +
                ", end=" + end +
                ", weight=" + weight +
                '}';
    }
}
public class Kruskal {
    private int edgeNum;//边的个数
    private char[] vertexs;//顶点数组
    private int[][] matrix;//领结矩阵
    //使用INF表示两个顶点不能连接
    private static final int INF=Integer.MAX_VALUE;
    public Kruskal(char[] vertexs,int[][] matrix){
        //初始化顶点和边的个数
        int vlen=vertexs.length;
        this.vertexs=new char[vlen];
        for(int i=0;i<vlen;i++){
            this.vertexs[i]=vertexs[i];
        }
        //初始化边
        this.matrix=new int[vlen][vlen];
        for(int i=0;i<vlen;i++){
            for(int j=0;j<vlen;j++){
                this.matrix[i][j]=matrix[i][j];
            }
        }
        for(int i=0;i<vlen;i++){
            for(int j=i+1;j<vlen;j++){
                if(this.matrix[i][j]!=INF){
                    edgeNum++;
                }
            }
        }
    }
    public void print(){
        System.out.println("输出邻接矩阵");
        for(int i=0;i<vertexs.length;i++){
            for(int j=0;j<vertexs.length;j++){
                System.out.printf("%15d",matrix[i][j]);
            }
            System.out.println();
        }
    }
    //对边进行排序
    public void sortEdge(EData[] data){
        for(int i=0;i<data.length-1;i++){
            for(int j=0;j<data.length;j++){
                if(data[i].weight<data[j].weight){
                    EData temp=data[j];
                    data[j]=data[i];
                    data[i]=temp;
                }
            }
        }
    }

    /**
     *
     * @param ch 顶点
     * @return 顶点在数组中对应的下标
     */
    private int getP(char ch){
        for(int i=0;i<vertexs.length;i++){
            if(vertexs[i]==ch){
                return i;
            }
        }
        return -1;
    }

    /**
     * 获取图中的边放到EDate中，需要遍历该数组
     *EData形式如['A','B',2]
     * @return
     */
    private EData[] getE(){
        int index =0;
        EData[] eData=new EData[edgeNum];
        for(int i=0;i<vertexs.length;i++){
            for(int j=i+1;j<vertexs.length;j++){
                if(matrix[i][j]!=INF){
                    eData[index++]=new EData(vertexs[i],vertexs[j],matrix[i][j]);
                }
            }
        }
        return eData;
    }
    private int getEnd(int[] ends,int i){
        while(ends[i]!=0){
            i=ends[i];
        }
        return i;
    }
    public void kk(){
        int index=0;//表示最后结果数组的索引
        int[] ends=new int[edgeNum];
        EData[] result=new EData[edgeNum];
        EData[] ed=getE();
        sortEdge(ed);
        //遍历
        for(int i=0;i<edgeNum;i++){
            //获取到第i条边的第一个顶点
            int p1=getP(ed[i].start);
            int p2=getP(ed[i].end);
            //获取p1这个顶点在已有最小生成树中的终点
            int m=getEnd(ends,p1);
            //获取p2这个顶点在已有最小生成树中的终点
            int n=getEnd(ends,p2);
            //是否构成回路
            if(m!=n){//未构成回路
                ends[m]=n;//设置m在已有最小生成树中的终点
                result[index++]=ed[i];
            }
        }
        //统计并打印最小生成树
        System.out.println(Arrays.toString(result));
    }
    public static void main(String[] args) {
        char[] vertexs={'A','B','C','D','E','F','G'};
        int[][] matrix={{0,3,INF,6,INF,2,INF},
                {5,0,INF,INF,7,9,4},
                {INF,5,0,INF,8,6,INF},
                {INF,INF,9,0,4,5,7},
                {6,INF,9,INF,0,INF,INF},
                {9,2,INF,8,INF,0,INF},
                {INF,7,4,3,INF,INF,0}};
        Kruskal kruskal = new Kruskal(vertexs, matrix);
        kruskal.print();
        EData[] eData=kruskal.getE();
        //System.out.println(Arrays.toString(kruskal.getE()));
        //kruskal.sortEdge(eData);
        //System.out.println(Arrays.toString(eData));
        kruskal.kk();
    }
}
