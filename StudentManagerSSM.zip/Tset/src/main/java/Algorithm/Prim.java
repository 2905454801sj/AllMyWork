package Algorithm;

import java.util.Arrays;

class Graph{
    int verx;//表示节点个数
    char[] data;//表示节点数据
    int[][] weight;//存放边
    public Graph(int verx){
        this.verx=verx;
        data=new char[verx];
        weight=new int[verx][verx];
    }
}
class minTree{
    public void createGraph(Graph graph,int verx,char data[],int[][] weight){
        int i,j;
        for(i=0;i<verx;i++){
            graph.data[i]=data[i];
            for(j=0;j<verx;j++){
                graph.weight[i][j]=weight[i][j];
            }
        }
    }
    //显示图的领结矩阵
    public void showGraph(Graph graph){
        for(int[] link:graph.weight){
            System.out.println(Arrays.toString(link));
        }
    }
    //编写prim算法

    /**
     *
     * @param graph 图
     * @param angle 从图的第几个顶点开始
     */
    public void prim(Graph graph,int angle){
        //visited表示节点是否被访问过
        int[] visited = new int[graph.verx];
        visited[angle]=1;//表示已访问
        //用h1，h2记录两个顶点的下标
        int h1=-1;
        int h2=-1;
        int minw=10000;
        for(int k=1;k<graph.verx;k++){//最少生成顶点数-1的路线
            for(int i=0;i<graph.verx;i++){
                for(int j=0;j<graph.verx;j++){
                    if(visited[i]==1&&visited[j]==0&&graph.weight[i][j]<minw){
                        //替换minw，寻找已访问过的节点和未访问过的节点的权值最小的边
                        minw=graph.weight[i][j];
                        h1=i;
                        h2=j;
                    }
                }
            }
            System.out.println("边 <"+graph.data[h1]+","+graph.data[h2]+"> 权值："+minw);
            //将h2节点置为已访问
            visited[h2]=1;
            minw=10000;
        }
    }
}
public class Prim {
    public static void main(String[] args) {
        char[] data= new char[]{'a','b','c','d','e','f','g'};
        int verx=data.length;
        int[][] weight=new int[][]{//10000表示无连通
                {10000,2,3,10000,5,10000,6},
                {4,10000,2,6,10000,10000,7},
                {3,2,5,10000,10000,10000,10000,6},
                {10000,1,10000,5,3,10000,10000},
                {4,6,10000,10000,3,7,10000},
                {10000,5,10000,4,6,10000,10000},
                {10000,7,5,4,10000,3,10000}
        };
        Graph graph=new Graph(verx);
        minTree minTree=new minTree();
        minTree.createGraph(graph,verx,data,weight);
        minTree.showGraph(graph);
        minTree.prim(graph,0);
    }
}
