package Algorithm;

public class ViolenceMatch {
    public static int vMatch(String s1,String s2){
        char[] s=s1.toCharArray();
        char[] a=s2.toCharArray();
        int s1l=s1.length();
        int s2l=s2.length();
        int i = 0;//s的索引
        int j = 0;//a的索引
        while(i<s1l&&j<s2l){
            if(s[i]==a[j]){
                i++;
                j++;
            }else{
                i=i-(j-1);
                j=0;
            }
        }
        //判断是否匹配成功
        if(j==s2l){
            return i-j;
        }else{
            return -1;
        }
    }
    public static void main(String[] args) {
        String a="asdadgfsagfag";
        String b="gfs";
        int i=vMatch(a,b);
        System.out.println(i);
    }
}

