package DataStructure;

//创建环形单项链表
class List3 {
	// 创建一个first节点，无编号
	private Jd first = new Jd(-1);

	// 添加节点，形成环形链表
	public void addJd(int nums) {
		if (nums < 1) {
			System.out.println("nums值不正确");
			return;
		}
		Jd cur = null;// 复制指针，帮助构造链表
		for (int i = 1; i <= nums; i++) {
			// 根据编号创建节点
			Jd jd1 = new Jd(i);
			if (i == 1) {
				first = jd1;
				first.setNext(first);// 构成环形链表
				cur = first;
			} else {
				cur.setNext(jd1);
				jd1.setNext(first);
				cur = jd1;
			}
		}
	}

	public void show() {
		if (first.getNext() == first) {
			System.out.println("链表为空");
			return;
		}
		Jd jd1 = first;
		while (true) {
			System.out.printf("编号为%d\n", jd1.getNo());
			if (jd1.getNext() == first) {
				break;
			}
			jd1 = jd1.getNext();
		}
	}

	public void countJd(int startno, int countno, int nums) {// 循环1,2报数，报到2的移除
		// 先对数据进行校验
		if (first.getNext() == first) {
			System.out.println("链表为空");
			return;
		}
		if (startno < 1 || startno > nums) {
			System.out.println("参数输入有误");
			return;
		}
		Jd help = first;
		// 先指向最后一个节点
		while (true) {
			if (help.getNext() == first) {
				break;
			}
			help = help.getNext();
		}
		// 先移动到开始的节点
		for (int j = 0; j < startno - 1; j++) {
			first = first.getNext();
			help = help.getNext();
		}
		while (true) {
			if (help == first) {// 说明圈中只有一人
				break;
			}
			for (int j = 0; j < countno - 1; j++) {
				first = first.getNext();
				help = help.getNext();
			}
			// first指向的节点需要移除
			System.out.printf("节点%d移除\n", first.getNo());
			first = first.getNext();
			help.setNext(first);
		}
		System.out.printf("最后编号为%d\n", first.getNo());
	}
}

//创建一个节点
class Jd {
	private int no;
	private Jd next;// 指向下一个节点，默认为空

	public Jd(int no) {
		this.no = no;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public Jd getNext() {
		return next;
	}

	public void setNext(Jd next) {
		this.next = next;
	}
}

public class CircleSingleLinkedList {

	public static void main(String[] args) {
		List3 aList = new List3();
		aList.addJd(5);
		aList.show();
		aList.countJd(2, 3, 5);
	}

}
