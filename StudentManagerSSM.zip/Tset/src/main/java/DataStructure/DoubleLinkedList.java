package DataStructure;

class List2 {
	public HeroNode2 head = new HeroNode2(0, "", "");

	public HeroNode2 getHead() {
		return head;
	}

	// 遍历双向链表
	public void list() {
		if (head.next == null) {
			System.out.println("双向链表为空");
			return;
		}
		HeroNode2 temp = head.next;
		while (true) {
			if (temp == null) {
				break;
			}
			System.out.println(temp);
			temp = temp.next;
		}
	}

	public void add(HeroNode2 heroNode) {
		// 因head不能动，因此需要一个辅助遍历temp
		HeroNode2 temp = head;
		// 遍历链表，找到最后
		while (true) {
			if (temp.next == null) {// 说明找到最后
				break;
			} // 如果没有到最后，将temp指向下一个节点
			temp = temp.next;
		}
		temp.next = heroNode;
		heroNode.pre = temp;
	}

	public void update(HeroNode2 heroNode) {
		if (head.next == null) {
			System.out.println("链表为空");
			return;
		}
		// 找到需要修改的节点
		HeroNode2 temp = head;
		boolean flag = false;
		while (true) {
			if (temp.next == null) {
				break;
			}
			if (temp.no == heroNode.no) {
				flag = true;
				break;
			}
			temp = temp.next;
		}
		if (flag) {
			temp.name = heroNode.name;
			temp.nickname = heroNode.nickname;
		} else {
			System.out.printf("未找到  %d 的节点\n", heroNode.no);
		}
	}

	// 删除节点
	public void delete(int no) {

		if (head.next == null) {
			System.out.println("链表为空");
			return;
		}
		HeroNode2 temp = head.next;
		boolean flag = false;
		while (true) {
			if (temp == null) {
				break;
			}
			if (temp.no == no) { // 已找到待删除的节点
				flag = true;
				break;
			}
			temp.next = temp;
		}
		if (flag) {
			temp.pre.next = temp.next;
			//防止被删除节点是最后一个节点
			if(temp.next!=null) {
				temp.next.pre = temp.pre;
			}
		} else {
			System.out.printf("要删除的节点 %d 不存在", no);
		}
	}
}

class HeroNode2 {
	public int no;
	public String name;
	public String nickname;
	public HeroNode2 next;// 指向下一节点，默认null
	public HeroNode2 pre;// 指向前一节点，默认null

	public HeroNode2(int no, String name, String nickname) {
		this.name = name;
		this.nickname = nickname;
		this.no = no;
	}

	public String toString() {
		return "HeroNode [no=" + no + ", name=" + name + ", nickname=" + nickname + "]";
	}

}

public class DoubleLinkedList {

	public static void main(String[] args) {
		HeroNode2 heroNode1 = new HeroNode2(1, "宋江", "及时雨");
		HeroNode2 heroNode2 = new HeroNode2(2, "卢俊义", "玉麒麟");
		HeroNode2 heroNode3 = new HeroNode2(3, "吴用", "智多星");
		HeroNode2 heroNode4 = new HeroNode2(4, "林冲", "豹子头");
		List2 list = new List2();
		list.add(heroNode1);
		list.add(heroNode2);
		list.add(heroNode3);
		list.add(heroNode4);
		list.list();
	}

}
