package DataStructure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

public class Graph {
    private ArrayList<String> vlist;//存储顶点的集合
    private int[][] edges;//存储图的对应的领结矩阵
    private int numOfedges;
    //定义数组Boolean[]记录某个节点是否被访问过
    private boolean[] isVisited;
    public Graph(int n){
        edges=new int[n][n];
        vlist=new ArrayList<String>(n);
        numOfedges=0;
        isVisited = new boolean[6];
    }
    public int getWeight(int v1,int v2){
        return edges[v1][v2];
    }
    public void InsertV(String s){
        vlist.add(s);
    }
    public void InsertE(int v1,int v2,int weight){
        edges[v1][v2]=weight;
        edges[v2][v1]=weight;
        numOfedges++;
    }
    public int getNumOfedges(){
        return numOfedges;
    }
    public int getNumOfVlist(){
        return vlist.size();
    }
    public String getValuebyIndex(int i){
        return vlist.get(i);
    }
    //得到第一个领结节点的下标
    public int getFirstN(int index){
        for(int j=0;j<vlist.size();j++){
            if(edges[index][j]>0){
                return j;
            }
        }
        return -1;
    }
    public int getNextN(int v1,int v2){
        for(int j=v2+1;j<vlist.size();j++){
            if(edges[v1][j]>0){
                return j;
            }
        }
        return -1;
    }
    //广度优先遍历
    private void BFS(boolean[] isv,int i){
        int a;//表示队列的头结点对应下标
        int b;//领结节点
        LinkedList<Object> objects = new LinkedList<>();
        System.out.print(getValuebyIndex(i)+"->");
        isVisited[i]=true;
        objects.addLast(i);
        while(!objects.isEmpty()){
            a=(Integer)objects.removeFirst();
            b=getFirstN(a);
            while(b!=-1){
                if(!isVisited[b]){
                    System.out.print(getValuebyIndex(b)+"->");
                    isVisited[b]=true;
                    objects.addLast(b);
                }
                b=getNextN(a,b);
            }
        }
    }
    //重载BFS
    private void BFS(){
        for(int i=0;i<getNumOfVlist();i++){
            if(!isVisited[i]){
                BFS(isVisited,i);
            }
        }
    }
    //深度优先遍历
    public void DFS(boolean[] isV,int i){
        System.out.print(getValuebyIndex(i)+"->");
        //将节点设置为已访问
        isVisited[i]=true;
        int w=getFirstN(i);
        while(w!=-1){
            if(!isVisited[w]){
                DFS(isV,w);
            }
            w=getNextN(i,w);
        }
    }
    //重载DFS方法
    public void DFS(){
        for(int i=0;i<getNumOfedges();i++){
            if(!isVisited[i]){
                DFS(isVisited,i);
            }
        }
    }
    public void show(){
        for(int[] ac:edges){
            System.out.println(Arrays.toString(ac));
        }
    }
    public static void main(String[] args){
        int n=6;
        String vv[]={"A","B","C","D","E","F"};
        Graph graph = new Graph(n);
        for(String vv1:vv){
            graph.InsertV(vv1);
        }
        graph.InsertE(1,2,3);
        graph.InsertE(2,3,4);
        graph.InsertE(3,4,5);
        graph.InsertE(4,2,6);
        graph.InsertE(5,0,7);
        graph.InsertE(0,1,8);
        graph.show();
        System.out.println("深度遍历");
        graph.DFS();
        System.out.println("广度遍历");
        //graph.BFS();
    }
}
