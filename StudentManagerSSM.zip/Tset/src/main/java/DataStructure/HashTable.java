package DataStructure;

import java.util.Scanner;

public class HashTable {
	// 哈希表
	static class Hashtab {
		private static EmpList[] lists;
		private static int size;

		public Hashtab(int size) {
			this.size = size;
			lists = new EmpList[size];
			// 分别初始化每一条链表
			for (int i = 0; i < size; i++) {
				lists[i] = new EmpList();
			}
		}

		public static void add(Emp emp) {
			int emoNO = hashfind(emp.id);
			// 加入到对应的链表
			lists[emoNO].add(emp);
		}

		// 编写一个散列函数,取模法
		public static int hashfind(int id) {
			return id % size;
		}

		public static void list() {
			for (int i = 0; i < size; i++) {
				lists[i].list(i);
			}
		}

		public static void findemp(int id) {
			int empno = hashfind(id);
			Emp emp = lists[empno].find(id);
			if (emp != null) {
				System.out.printf("在第%d个", (empno + 1));
			} else {
				System.out.println("未找到");
			}
		}
	}

	// 表示雇员
	static class Emp {
		public int id;
		public String name;
		public Emp next;

		public Emp(int id, String name) {
			super();
			this.id = id;
			this.name = name;
		}
	}

	// 创建一条链表
	static class EmpList {
		// 头指针，指向雇员
		private Emp head;// 默认null

		public void add(Emp emp) {
			// 如果添加第一个雇员
			if (head == null) {
				head = emp;
				return;
			}
			// 若不是，使用辅助指针帮助定位到最后
			Emp tempEmp = head;
			while (true) {
				if (tempEmp == null) {// 说明到链表最后
					break;
				}
				tempEmp = tempEmp.next;
			}
			tempEmp.next = emp;
		}

		public void list(int no) {
			if (head == null) {
				System.out.println("链表为空");
				return;
			}
			Emp tempEmp = head;
			while (true) {
				System.out.printf("第 %d 个链表 => id=%d name=%s\n", no, tempEmp.id, tempEmp.name);
				if (tempEmp.next == null) {
					break;
				} else {
					tempEmp = tempEmp.next;
				}
			}
		}

		// 根据id查找雇员，若找到则返回emp，如果没有找到返回null
		public Emp find(int id) {
			if (head == null) {
				System.out.println("链表为空");
				return null;
			}
			Emp tempEmp = head;
			while (true) {
				if (tempEmp.id == id) {
					break;
				}
				// 退出
				if (tempEmp.next == null) {
					System.out.println("未找到");
					tempEmp = null;
					break;
				}
				tempEmp = tempEmp.next;
			}
			return tempEmp;
		}
	}

	public static void main(String[] args) {
		Hashtab hash = new Hashtab(7);
		String keyString = "";
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("add");
			System.out.println("show");
			System.out.println("exit");
			System.out.println("find");
			keyString = scanner.next();
			switch (keyString) {
			case "add":
				System.out.println("输入ID");
				int id = scanner.nextInt();
				System.out.println("输入名字");
				String nameString = scanner.next();
				Emp emp = new Emp(id, nameString);
				Hashtab.add(emp);
				break;
			case "show":
				Hashtab.list();
				break;
			case "exit":
				scanner.close();
				System.exit(0);
			case "find":
				System.out.println("输出需要查找的id\n");
				id = scanner.nextInt();
				Hashtab.findemp(id);
			default:
				break;
			}
		}
	}
}
