package DataStructure;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Stack;

//比较运算符优先级
class pp {
	private static int add = 1;
	private static int sub = 1;
	private static int mul = 2;
	private static int div = 2;

	// 返回对应优先级
	public static int getValue(String pp) {
		int res = 0;
		switch (pp) {
		case "+":
			res = add;
			break;
		case "-":
			res = sub;
			break;
		case "*":
			res = mul;
			break;
		case "/":
			res = div;
			break;
		default:
			res = 0;
			break;
		}
		return res;
	}
}

public class PolandNotation {
	public static List<String> parseList(List<String> ls) {
		Stack<String> s1 = new Stack<>();// 符号栈
		List<String> s2 = new ArrayList();// 存放中间结果的栈
		for (String item : ls) {
			if (item.matches("\\d+")) {
				s2.add(item);
			} else if (item.equals("(")) {
				s1.push(item);
			} else if (item.equals(")")) {
				while (!s1.peek().equals("(")) {
					s2.add(s1.pop());
				}
				s1.pop();
			} else {
				// 当item的优先级小于栈顶运算符优先级,将s1栈顶的运算符弹出并压入s2中
				while (s1.size() != 0 && pp.getValue(s1.peek()) >= pp.getValue(item)) {
					s2.add(s1.pop());
				}
				s1.push(item);
			}
		}
		while (s1.size() != 0) {
			s2.add(s1.pop());
		}
		return s2;
	}

	// 中缀表达式转后缀表达式
	public static List<String> changeList(String s) {
		List<String> lStrings = new ArrayList<String>();
		int i = 0;// 临时指针用于遍历中缀表达式
		String string;// 用于多位数的拼接
		char c;// 遍历每一个字符放到c中
		do {
			// 如果c非数字，需要加入到ls
			if ((c = s.charAt(i)) < 48 || (c = s.charAt(i)) > 57) {
				lStrings.add("" + c);
				i++;
			} else {// 如果是一个数，要考虑多位数
				string = "";
				while (i < s.length() && (c = s.charAt(i)) >= 48 && (c = s.charAt(i)) <= 57) {
					string += c;
					i++;
				}
				lStrings.add(string);
			}
		} while (i < s.length());
		return lStrings;
	}

	// 将表达式全部放到arraylist中
	private static List<String> getlistString(String pnString) {
		String[] split = pnString.split(" ");// 以空格分开
		List<String> list = new ArrayList<String>();
		for (String ele : split) {
			list.add(ele);
		}
		return list;
	}

	// 完成逆波兰表达式计算
	public static int cal(List<String> ls) {
		Stack<String> stack = new Stack<String>();
		// 遍历list
		for (String item : ls) {
			// 使用正则表达式取出数
			if (item.matches("\\d+")) {// 匹配的是多位数
				// 入栈
				stack.push(item);
			} else {
				int n2 = Integer.parseInt(stack.pop());
				int n1 = Integer.parseInt(stack.pop());
				int res = 0;
				if (item.equals("+")) {
					res = n1 + n2;
				} else if (item.equals("-")) {
					res = n1 - n2;
				} else if (item.equals("*")) {
					res = n1 * n2;
				} else if (item.equals("/")) {
					res = n1 / n2;
				} else {
					throw new RuntimeException("运算符有误");
				}
				// res入栈
				stack.push(res + "");
			}
		}
		return Integer.parseInt(stack.pop());
	}

	public static void main(String[] args) {

		String exString = "2+3*(3+7)/5";
		List<String> cList = changeList(exString);
		System.out.println("中缀表达式=" + cList);
		List<String> pList = parseList(cList);
		System.out.println("后缀表达式=" + pList);
		// 先定义一个逆波兰表达式,(3+4)*5-6
		/*
		 * String pnString = "3 4 + 5 * 6 -"; List<String> pnList =
		 * getlistString(pnString); System.out.println(pnList); int res = cal(pnList);
		 * System.out.println(res);
		 */
	}

}
