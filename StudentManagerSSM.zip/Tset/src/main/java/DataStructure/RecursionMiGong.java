package DataStructure;

public class RecursionMiGong {
	// 最短路径
	public static int Shortest(int[][] map) {
		int count = 0;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 7; j++) {
				if (map[i][j] == 2) {
					count++;
				}
			}
		}
		return count;
	}

	// 小球找路
	public static boolean setWay(int[][] map, int i, int j) {
		// i,j表示从哪里开始找,找到路返回true，小球找到[6][5]即为找到出口
		// 当map[i][j]=0表示没有走过这条路，=1表示墙，=2表示可走，=3表示已经走过
		// 指定策略，下-》右-》上-》左
		if (map[6][5] == 2) {
			return true;
		} else {
			if (map[i][j] == 0) {
				map[i][j] = 2;// 假设可以走通
				if (setWay(map, i + 1, j)) {
					return true;
				} else if (setWay(map, i, j + 1)) {
					return true;
				} else if (setWay(map, i - 1, j)) {
					return true;
				} else if (setWay(map, i, j - 1)) {
					return true;
				} else {
					// 说明该点走不通
					map[i][j] = 3;
					return false;
				}
			} else {// 如果map[i][j]！=0，可能是1,2,3
				return false;
			}
		}
	}

	public static boolean setWay2(int[][] map, int i, int j) {
		// i,j表示从哪里开始找,找到路返回true，小球找到[6][5]即为找到出口
		// 当map[i][j]=0表示没有走过这条路，=1表示墙，=2表示可走，=3表示已经走过
		// 指定策略，上-》右-》下-》左
		if (map[6][5] == 2) {
			return true;
		} else {
			if (map[i][j] == 0) {
				map[i][j] = 2;// 假设可以走通
				if (setWay(map, i - 1, j)) {
					return true;
				} else if (setWay(map, i, j + 1)) {
					return true;
				} else if (setWay(map, i + 1, j)) {
					return true;
				} else if (setWay(map, i, j - 1)) {
					return true;
				} else {
					// 说明该点走不通
					map[i][j] = 3;
					return false;
				}
			} else {// 如果map[i][j]！=0，可能是1,2,3
				return false;
			}
		}
	}

	public static void main(String[] args) {
		// 创建二维数组模拟迷宫
		int[][] map = new int[8][7];
		// 1表示墙
		for (int i = 0; i < 7; i++) {
			map[0][i] = 1;
			map[7][i] = 1;
		}
		for (int i = 0; i < 8; i++) {
			map[i][0] = 1;
			map[i][6] = 1;
		}
		// 输出地图
		System.out.println("地图");
		map[3][1] = 1;
		map[3][2] = 1;
		// map[1][2] = 1;
		// map[2][2] = 1;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 7; j++) {
				System.out.print(map[i][j] + " ");
			}
			System.out.println();
		}
		setWay2(map, 1, 1);
		System.out.println();
		map[3][1] = 1;
		map[3][2] = 1;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 7; j++) {
				System.out.print(map[i][j] + " ");
			}
			System.out.println();
		}

	}

}
