package DataStructure;

import java.lang.reflect.Array;

public class RecursionQueue8 {
	// 定义一个max表示多少个皇后，定义数组表示皇后放置的结果
	static int max = 8;
	static int[] array = new int[max];
	// 输出皇后的位置
	static int count = 0;

	private static void print() {
		for (int i = 0; i < array.length; i++) {
			System.out.printf(array[i] + " ");
		}
		System.out.println();
	}

	// 判断当前皇后是否与其他皇后冲突
	public static boolean judge(int n) {
		for (int i = 0; i < n; i++) {
			// array[i]==array[n]判断皇后是否在同一列
			// Math.abs(n-i)==Math.abs(array[n]-array[i])判断是都在同一斜线
			if (array[i] == array[n] || Math.abs(n - i) == Math.abs(array[n] - array[i])) {
				return false;
			}
		}
		return true;
	}

	public static void check(int n) {
		if (n == max) {
			print();
			count++;
			return;
		}
		for (int i = 0; i < max; i++) {
			array[n] = i;
			if (judge(n)) {
				check(n + 1);
			}
			// 如果冲突，则继续执行array[n]=i;即将第n个皇后放置在本行的后移的一个位置
		}
	}

	public static void main(String[] args) {
		RecursionQueue8 queue8 = new RecursionQueue8();
		queue8.check(0);
		System.out.printf("一共有%d 个解法", count);
	}

}
