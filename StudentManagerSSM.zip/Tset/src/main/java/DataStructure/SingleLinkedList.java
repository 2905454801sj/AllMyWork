package DataStructure;

class List {
	// 初始化一个头结点，头结点不能动
	private HeroNode head = new HeroNode(0, "", "");

	public HeroNode getHead() {
		return head;
	}

	// 添加节点到单向链表，不考虑编号的顺序，找到当前节点的最后节点，将最后节点的next指向下一节点
	public void add(HeroNode heroNode) {
		// 因head不能动，因此需要一个辅助遍历temp
		HeroNode temp = head;
		// 遍历链表，找到最后
		while (true) {
			if (temp.next == null) {// 说明找到最后
				break;
			} // 如果没有到最后，将temp指向下一个节点
			temp = temp.next;
		}
		temp.next = heroNode;

	}

	// 修改节点信息，根据编号修改，根据no修改
	public void update(HeroNode heroNode) {
		if (head.next == null) {
			System.out.println("链表为空");
			return;
		}
		// 找到需要修改的节点
		HeroNode temp = head;
		boolean flag = false;
		while (true) {
			if (temp.next == null) {
				break;
			}
			if (temp.no == heroNode.no) {
				flag = true;
				break;
			}
			temp = temp.next;
		}
		if (flag) {
			temp.name = heroNode.name;
			temp.nickname = heroNode.nickname;
		} else {
			System.out.printf("未找到  %d 的节点\n", heroNode.no);
		}
	}

	// 单链表反转
	public static void reverseList(HeroNode head) {
		if (head.next == null || head.next.next == null) {
			return;
		}
		// 定义辅助指针，帮助遍历原来链表
		HeroNode cNode = head.next;
		HeroNode nextNode = null;// 指向当前cNode节点的下一个节点
		HeroNode reverseHead = new HeroNode(0, "", "");
		// 将原来的链表遍历并取出，依次装在新的链表最前端
		while (cNode != null) {
			nextNode = cNode.next;
			cNode.next = reverseHead.next;
			reverseHead.next = cNode;
			cNode = nextNode;
		}
		// 将head.next指向reversehead.next
		head.next = reverseHead.next;
	}

	// 显示链表
	public void showList() {
		// 判断链表是否为空
		if (head.next == null) {
			System.out.println("链表为空");
			return;
		}
		// 头结点不能动，需要一个辅助节点
		HeroNode temp = head.next;
		while (true) {
			if (temp == null) {
				break;
			}
			System.out.println(temp);
			temp = temp.next;
		}
	}

	// 删除节点
	public void delete(int no) {
		HeroNode temp = head;
		boolean flag = false;
		while (true) {
			if (temp.next == null) {
				break;
			}
			if (temp.next.no == no) { // 已找到待删除的节点的前面一个节点
				flag = true;
				break;
			}
			temp = temp.next;
		}
		if (flag) {
			temp.next = temp.next.next;
		} else {
			System.out.printf("要删除的节点 %d 不存在", no);
		}
	}

	public void addByOrder(HeroNode heroNode) {
		// 头结点不能动，通过辅助变量帮助找到添加的位置
		HeroNode temp = head;
		boolean flag = false;// flag表示编号是否存在
		while (true) {
			if (temp.next == null) {
				break;
			}
			if (temp.next.no > heroNode.no) {// 位置已找到，在temp后面插入
				break;
			} else if (temp.next.no == heroNode.no) {// 说明编号已存在
				flag = true;
				break;
			}
			temp = temp.next;
		}
		// 判断flag
		if (flag) {
			System.out.printf("准备插入的英雄  %d 的编号已存在\n", heroNode.no);
		} else {
			// 插入到链表中
			heroNode.next = temp.next;
			temp.next = heroNode;
		}
	}
}

class HeroNode {
	public int no;
	public String name;
	public String nickname;
	public HeroNode next;

	public HeroNode(int no, String name, String nickname) {
		this.name = name;
		this.nickname = nickname;
		this.no = no;
	}

	public String toString() {
		return "HeroNode [no=" + no + ", name=" + name + ", nickname=" + nickname + "]";
	}

}

public class SingleLinkedList {

	public static void main(String[] args) {
		HeroNode heroNode1 = new HeroNode(1, "宋江", "及时雨");
		HeroNode heroNode2 = new HeroNode(2, "卢俊义", "玉麒麟");
		HeroNode heroNode3 = new HeroNode(3, "吴用", "智多星");
		HeroNode heroNode4 = new HeroNode(4, "林冲", "豹子头");
		List list = new List();

		// list.add(heroNode3);
		// list.add(heroNode1);
		// list.add(heroNode4);
		// list.add(heroNode2);

		list.addByOrder(heroNode3);
		list.addByOrder(heroNode1);
		list.addByOrder(heroNode4);
		list.addByOrder(heroNode2);
		// list.showList();

		// System.out.println("反转后");
		// reverseList(list.getHead());
		// list.showList();
		System.out.println("删除后");
		list.delete(2);
		list.showList();

	}

	// 单链表反转
	private static void reverseList(HeroNode head) {
		if (head.next == null || head.next.next == null) {
			return;
		}
		// 定义辅助指针，帮助遍历原来链表
		HeroNode cNode = head.next;
		HeroNode nextNode = null;// 指向当前cNode节点的下一个节点
		HeroNode reverseHead = new HeroNode(0, "", "");
		// 将原来的链表遍历并取出，依次装在新的链表最前端
		while (cNode != null) {
			nextNode = cNode.next;
			cNode.next = reverseHead.next;
			reverseHead.next = cNode;
			cNode = nextNode;
		}
		// 将head.next指向reversehead.next
		head.next = reverseHead.next;
	}

}
