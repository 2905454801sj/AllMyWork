package DataStructure;

import java.util.Stack;

public class Stack1 {

	public static void main(String[] args) {
		Stack<String> stack = new Stack<String>();
		stack.add("J");
		stack.add("a");
		stack.add("s");
		while (stack.size() > 0) {
			System.out.println(stack.pop());
		}
	}

}
