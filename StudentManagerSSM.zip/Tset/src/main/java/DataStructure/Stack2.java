package DataStructure;

import java.util.Scanner;

import javax.management.RuntimeErrorException;

class Stack {
	private int maxSize;
	private int[] stack;
	private int top = -1;

	public Stack(int maxSize) {
		this.maxSize = maxSize;
		stack = new int[this.maxSize];
	}

	// 栈满
	public boolean isFull() {
		return top == maxSize - 1;
	}

	// 栈空
	public boolean isEmpty() {
		return top == -1;
	}

	// 入栈
	public void push(int value) {
		if (isFull()) {
			System.out.println("栈满");
			return;
		}
		top++;
		stack[top] = value;
	}

	// 出栈
	public int pop() {
		if (isEmpty()) {
			throw new RuntimeException("栈空");
		}
		int value = stack[top];
		top--;
		return value;
	}

	// 遍历，从栈顶开始遍历
	public void show() {
		if (isEmpty()) {
			System.out.println("栈空");
			return;
		}
		for (int i = top; i >= 0; i--) {
			System.out.println(stack[i]);
		}
	}
}

public class Stack2 {

	public static void main(String[] args) {
		Stack stack = new Stack(5);
		String keyString = "";
		boolean loop = true;
		Scanner scanner = new Scanner(System.in);
		while (loop) {
			System.out.println("show:显示");
			System.out.println("push:添加");
			System.out.println("pop:删除");
			System.out.println("exit:退出");
			System.err.println("请输入");
			keyString = scanner.next();
			switch (keyString) {
			case "show":
				stack.show();
				break;
			case "push":
				System.out.println("请输入一个数");
				int value = scanner.nextInt();
				stack.push(value);
				break;
			case "pop":
				try {
					int result = stack.pop();
					System.out.printf("取出数据  %d\n", result);
				} catch (Exception e) {
					// TODO: handle exception
				}
				break;
			case "exit":
				scanner.close();
				loop = false;
				break;
			default:
				break;
			}
		}
		System.out.println("程序退出");
	}

}
