package DataStructure;

class Stack3 {
	private int maxSize;
	private int[] stack;
	private int top = -1;

	public Stack3(int maxSize) {
		this.maxSize = maxSize;
		stack = new int[this.maxSize];
	}

	public int peek() {
		return stack[top];
	}

	// 栈满
	public boolean isFull() {
		return top == maxSize - 1;
	}

	// 栈空
	public boolean isEmpty() {
		return top == -1;
	}

	// 入栈
	public void push(int value) {
		if (isFull()) {
			System.out.println("栈满");
			return;
		}
		top++;
		stack[top] = value;
	}

	// 出栈
	public int pop() {
		if (isEmpty()) {
			throw new RuntimeException("栈空");
		}
		int value = stack[top];
		top--;
		return value;
	}

	// 遍历，从栈顶开始遍历
	public void show() {
		if (isEmpty()) {
			System.out.println("栈空");
			return;
		}
		for (int i = top; i >= 0; i--) {
			System.out.println(stack[i]);
		}
	}

	// 返回运算符的优先级
	public int priority(int i) {
		if (i == '*' || i == '/') {
			return 1;
		} else if (i == '+' || i == '-') {
			return 0;
		} else {
			return -1;
		}
	}

	// 判断是否运算符
	public boolean isOper(char val) {
		return val == '+' || val == '-' || val == '*' || val == '/';
	}

	public int cal(int n1, int n2, int oper) {
		int res = 0;
		switch (oper) {
		case '+':
			res = n1 + n2;
			break;
		case '-':
			res = n2 - n1;
			break;
		case '*':
			res = n1 * n2;
			break;
		case '/':
			res = n2 / n1;
			break;
		default:
			break;
		}
		return res;
	}
}

public class StackCalculator {

	public static void main(String[] args) {
		String exString = "20-8-6+9";
		Stack3 numStack3 = new Stack3(10);
		Stack3 operStack3 = new Stack3(10);
		int index = 0;// 用于扫描数字或运算符
		int num1 = 0;
		int num2 = 0;
		int oper = 0;
		int res = 0;
		char ch = ' ';
		String aString = "";// 用于拼接多位数
		while (true) {
			// 依次得到exString的每个字符
			// 由于是一位一位扫描，所以两位数以上的计算无法解决，需要判断数字下一位是否还是数字
			ch = exString.substring(index, index + 1).charAt(0);
			// 判断符号优先级，若符号栈为空则直接入栈，若符号优先级大于前一个则先计算优先级大的，反之则继续入栈
			if (operStack3.isOper(ch)) {
				if (operStack3.isEmpty()) {
					operStack3.push(ch);
				} else {
					if (operStack3.priority(ch) <= operStack3.priority(operStack3.peek())) {
						num1 = numStack3.pop();
						num2 = numStack3.pop();
						oper = operStack3.pop();
						res = numStack3.cal(num1, num2, oper);
						numStack3.push(res);
						operStack3.push(ch);
					} else {
						operStack3.push(ch);
					}
				}
			} else {
				// numStack3.push(ch - 48);// ASCII码
				aString += ch;
				// 如果ch已经是aString 最后一位，直接入栈
				if (index == exString.length() - 1) {
					numStack3.push(Integer.parseInt(aString));
				} else {
					// 判断下一个字符是不是数字,如果是数字就继续扫描
					if (operStack3.isOper(exString.substring(index + 1, index + 2).charAt(0))) {
						// 如果后一位是运算符则入栈
						numStack3.push(Integer.parseInt(aString));
						// 必须将aString清空
						aString = "";
					}
				}
			}
			// 让index+1并判断是否已扫描完
			index++;
			if (index >= exString.length()) {
				break;
			}
		}
		while (true) {
			// 如果符号栈为空，则计算结束,数栈中只有一个数，即结果
			if (operStack3.isEmpty()) {
				break;
			}
			num1 = numStack3.pop();
			num2 = numStack3.pop();
			oper = operStack3.pop();
			res = numStack3.cal(num1, num2, oper);
			numStack3.push(res);
		}
		System.out.println(numStack3.pop());
	}

}
