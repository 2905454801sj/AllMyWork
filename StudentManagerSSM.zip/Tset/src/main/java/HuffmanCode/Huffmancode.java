package HuffmanCode;

import java.io.*;
import java.util.*;

class Node implements Comparable<Node>{
    Byte date;//存放数据
    int weight;//权值
    Node left;
    Node right;
    public Node(Byte date,int weight){
        this.date=date;
        this.weight=weight;
    }
    @Override
    public int compareTo(Node o) {
        //从小到大
        return this.weight-o.weight;
    }

    @Override
    public String toString() {
        return "Node{" +
                "date=" + date +
                ", weight=" + weight ;
    }
    public void preOrder(){
        System.out.println(this);
        if(this.left!=null){
            this.left.preOrder();
        }
        if(this.right!=null){
            this.right.preOrder();
        }
    }
}
public class Huffmancode {
    private static List<Node> getNodes(byte[] bytes){
        //创建arraylist
        ArrayList<Node> nodes=new ArrayList<>();
        //存储每个byte出现次数
        Map<Byte,Integer> counts=new HashMap<>();
        for(byte b:bytes){
            Integer count=counts.get(b);
            if(count==null){//map无字符数据
                counts.put(b,1);
            }else{
                counts.put(b,count+1);
            }
        }
        //把每个键值对转化为nodes，加入到nodes集合
        for(Map.Entry<Byte,Integer> entry: counts.entrySet()){//遍历map
            nodes.add(new Node(entry.getKey(),entry.getValue()));
        }
        return nodes;
    }
    //生成赫夫曼编码
    static Map<Byte,String> hfCode=new HashMap<Byte,String>();
    static StringBuilder stringBuilder=new StringBuilder();
    //编写方法压缩文件
    public static void zipFile(String src,String add){
        FileInputStream fileInputStream=null;
        FileOutputStream fileOutputStream=null;
        ObjectOutputStream objectOutputStream = null;
        try {
            //创建输入流
            fileInputStream=new FileInputStream(src);
            //创建一个和源文件一样大小的byte
            byte[] b=new byte[fileInputStream.available()];
            //读取文件
            fileInputStream.read(b);
            //直接对源文件压缩
            byte[] hffilezip=hfzip(b);
            //创建文件的输出流，存放压缩文件
            fileOutputStream=new FileOutputStream(add);
            //创建一个和文件输出流关联的objectOutputStream
            objectOutputStream=new ObjectOutputStream(fileOutputStream);
            //把赫夫曼编码的字节数组写入压缩文件
            objectOutputStream.writeObject(hffilezip);
            //以对象流的方式写入赫夫曼编码，方便会服源文件使用
            objectOutputStream.writeObject(hfCode);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }finally {
            try {
                fileInputStream.close();
                fileOutputStream.close();
                objectOutputStream.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
    }
    //编写方法解压文件
    public static void unZip(String src,String add) {
        InputStream inputStream=null;
        ObjectInputStream objectInputStream=null;
        OutputStream outputStream=null;
        try{
            inputStream=new FileInputStream(src);
            objectInputStream=new ObjectInputStream(inputStream);
            byte[] b=(byte[])objectInputStream.readObject();
            Map<Byte,String> codes=(Map<Byte,String>)objectInputStream.readObject();
            //解码
            byte[] c=decode(hfCode,b);
            outputStream=new FileOutputStream(add);
            outputStream.write(c);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }finally {
            try {
                outputStream.close();
                objectInputStream.close();
                inputStream.close();
            }catch (Exception e1){
                System.out.println(e1.getMessage());
            }
        }
    }
    //为了方便调用，重载getcode
    private static Map<Byte,String> getCodes(Node root){
        if(root==null){
            return null;
        }
        //处理root左子树
        getCode(root.left,"0",stringBuilder);
        getCode(root.right,"1",stringBuilder);
        return hfCode;
    }
    //使用一个方法封装前面的方法，方便调用
    private static byte[] hfzip(byte[] bytes){
        List<Node> nodes=getNodes(bytes);
        Node hftreeroot=createHT(nodes);
        Map<Byte,String> hfcode=getCodes(hftreeroot);
        byte[] bytes1=zip(bytes,hfcode);
        return bytes1;
    }
    //通过生成的赫夫曼编码返回一个赫夫曼编码压缩后的byte[]
    /**
     *
     * @param b 原始字符串对应的byte
     * @param hfCode 生成的赫夫曼编码
     * @return
     */
    private static byte[] zip(byte[] b,Map<Byte,String> hfCode){
        StringBuilder stringBuilder=new StringBuilder();
        for(byte a:b){
            stringBuilder.append(hfCode.get(a));
        }
        int len;
        if(stringBuilder.length()%8==0){
            len=stringBuilder.length()/8;
        }else{
            len=stringBuilder.length()/8+1;
        }
        //创建压缩存储后的byte数组
        byte[] hfcodebyte=new byte[len];
        int index=0;
        for(int i=0;i<stringBuilder.length();i+=8){//每八位对应一个byte
            String str;
            if(i+8>stringBuilder.length()){
                str=stringBuilder.substring(i);
            }else{
                str = stringBuilder.substring(i, i + 8);
            }
            //将str转成byte，放入到hfcode
            hfcodebyte[index]=(byte)Integer.parseInt(str,2);
            index++;
        }
        return hfcodebyte;
    }
    /**
     *将所有叶子结点的编码得到并放入到hfcode集合中
     * @param node 传入结点
     * @param code 路径：左子节点为0，右子节点为1
     * @param stringBuilder 用于拼接路径
     */
    private static void getCode(Node node,String code,StringBuilder stringBuilder){
        StringBuilder stringBuilder1=new StringBuilder(stringBuilder);
        stringBuilder1.append(code);
        if(node!=null){
            //判断当前节点是否为叶子结点
            if(node.date==null){//非叶子结点
                //向左递归处理
                getCode(node.left,"0",stringBuilder1);
                //向右递归
                getCode(node.right,"1",stringBuilder1);
            }else{//叶子结点
                hfCode.put(node.date, stringBuilder1.toString());
            }
        }
    }
    private static byte[] decode(Map<Byte,String> hfmancode,byte[] hfmanbyte){
        //先得到hfmancode对应的二进制字符串
        StringBuilder stringBuilder=new StringBuilder();
        //将byte数组转化成二进制的字符串
        for(int i=0;i<hfmanbyte.length;i++){
            byte b=hfmanbyte[i];
            boolean flag=(i==hfmanbyte.length-1);
            stringBuilder.append(byteToBitString(!flag,b));
        }
        Map<String,Byte> map=new HashMap<String, Byte>();
        for(Map.Entry<Byte,String> entry:hfmancode.entrySet()){
            map.put(entry.getValue(),entry.getKey());
        }
        //创建集合
        List<Byte> list=new ArrayList<>();
        for(int i=0;i<stringBuilder.length();){
            int count=1;
            boolean flag=true;
            Byte b=null;
            while(flag){
                //取出一个'1','0'
                String key=stringBuilder.substring(i,i+count);//i不动，让count移动，指定匹配到一个字符
                b=map.get(key);
                if(b==null){//未匹配到
                    count++;
                }else{
                    //匹配到
                    flag=false;
                }
            }
            list.add(b);
            i+=count;//i直接移动到count的位置
        }
        //for循环结束，list中已存放所有字符
        byte b[]=new byte[list.size()];
        for(int i=0;i<b.length;i++){
            b[i]=list.get(i);
        }
        return b;
    }
    //完成数据的解压
    private static String byteToBitString(boolean flag,byte b){//flag 表示是否需要补高位
        int temp=b;
        if(flag){
            temp|=256;
        }
        String str=Integer.toBinaryString(temp);//返回的是temp的补码
        if(flag) {
            return str.substring(str.length() - 8);
        }else{
            return str;
        }
    }
    private static void preOrder(Node root){
        if(root!=null){
            root.preOrder();
        }else{
            System.out.println("赫夫曼树为空");
        }
    }
    //通过list创建赫夫曼树
    private static Node createHT(List<Node> nodes){
        while(nodes.size()>1){
            Collections.sort(nodes);
            //取出第一颗最小的二叉树
            Node left=nodes.get(0);
            //取出第二颗最小的二叉树
            Node right=nodes.get(1);
            //创建一颗新的二叉树，根节点无date只有权值
            Node parent=new Node(null,left.weight+right.weight);
            parent.left=left;
            parent.right=right;
            nodes.remove(left);
            nodes.remove(right);
            nodes.add(parent);
        }
        //返回的节点
        return nodes.get(0);
    }
    public static void main(String[] args)  {
        /*String s="i like java and anyone";
        byte[] b=s.getBytes();
        *//*List<Node> nodes=getNodes(b);
        Node a=createHT(nodes);
        System.out.println(nodes);
        a.preOrder();
        getCode(a,"",stringBuilder);
        System.out.println("赫夫曼编码表："+   hfCode);
        byte[] as=zip(b,hfCode);
        System.out.println(Arrays.toString(as));*//*
        byte[] hfcodebyte=hfzip(b);
        System.out.println("压缩后结果为："+Arrays.toString(hfcodebyte));
        byte[] source=decode(hfCode,hfcodebyte);
        System.out.println("原字符串："+new String(source));*/
        //测试压缩文件
        /*String src="C://Users//Lenovo//Desktop//1.png";
        String add="C://Users//Lenovo//Desktop//2.zip";
        zipFile(src,add);
        System.out.println("压缩完成");*/
        //测试解压文件
        String src="C://Users//Lenovo//Desktop//2.zip";
        String add="C://Users//Lenovo//Desktop//3.png";
        unZip(src,add);
        System.out.println("解压成功");
    }
}
