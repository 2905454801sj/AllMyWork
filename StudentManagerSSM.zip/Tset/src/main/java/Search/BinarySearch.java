package Search;

import java.util.ArrayList;
import java.util.List;

public class BinarySearch {
	// 二分查找
	// 前提是该数组必须有序
	public static ArrayList<Integer> binary2(int[] arr, int left, int right, int value) {
		// 当left大于right，应该结束递归
		if (left > right) {
			return new ArrayList<Integer>();
		}
		int mid = (left + right) / 2;
		int midv = arr[mid];
		if (midv < value) {// 向右递归
			return binary2(arr, mid + 1, right, value);
		} else if (midv > value) {
			return binary2(arr, left, mid - 1, value);
		} else {
			ArrayList<Integer> rlist=new ArrayList<Integer>();
			int temp=mid-1;
			while(true) {
				if(temp<0||arr[temp]!=value) {
					break;	
				}
				rlist.add(temp);
				temp--;
			}
			rlist.add(mid);
			temp=mid+1;
			while(true) {
				if(temp>arr.length-1||arr[temp]!=value) {
					break;	
				}
				rlist.add(temp);
				temp++;
			}
			return rlist;
		}
	}

	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		ArrayList<Integer> index = binary2(arr, 0, arr.length - 1, 5);
		System.out.println(index);
	}

}
