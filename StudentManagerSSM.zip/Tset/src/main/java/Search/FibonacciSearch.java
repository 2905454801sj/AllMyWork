package Search;

import java.util.Arrays;

public class FibonacciSearch {
	// 斐波那契查找
	// mid=low+f(k-1)-1
	public static int maxsize = 20;

	public static int[] fbl() {
		int[] a = new int[maxsize];
		a[0] = 1;
		a[1] = 1;
		for (int i = 2; i < maxsize; i++) {
			a[i] = a[i - 1] + a[i - 2];
		}
		return a;
	}

	/*
	 * key 查找的关键值
	 */
	public static int fbl(int[] arr, int key) {
		int low = 0;
		int high = arr.length - 1;
		int k = 0;// 表示斐波那契数列分割数值的下标
		int mid = 0;
		int a[] = fbl();
		// 获取斐波那契分割数值的下标
		while (high > a[k] - 1) {
			k++;
		}
		// 因为a[k]可能大于数组的长度，需要使用array类，构造一个新的数组并指向arr[]
		// 不足的部分会使用0填充
		int[] temp = Arrays.copyOf(arr, a[k]);
		// 需要使用arr数组最后的数填充temp
		for (int i = high + 1; i < temp.length; i++) {
			temp[i] = a[high];
		}
		// 用while循环来找到key
		while (low <= high) {
			mid = low + a[k - 1] - 1;
			if (key < temp[mid]) {// 说明应该继续向前查找
				high = mid - 1;
				k--;
			} else if (key > temp[mid]) {
				low = mid + 1;
				k -= 2;
			} else {
				if (mid <= high) {
					return mid;
				} else {
					return high;
				}
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		int[] arr = { 1, 3, 5, 7, 9, 11, 13, 15, 17 };
		System.out.println(fbl(arr, 11));
	}

}
