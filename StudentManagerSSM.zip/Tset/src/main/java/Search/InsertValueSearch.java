package Search;

public class InsertValueSearch {
	// 插值查找,要求数组有序,表内数值不均匀的时候，不一定比二分查找好。
	public static int Ivs(int[] arr, int left, int right, int value) {
		int q = 1;
		System.out.println("查找了第" + q + "次");
		q++;
		if (left > right || value < arr[0] || value > arr[arr.length - 1]) {
			return -1;
		}
		// 插值查找公式
		int mid = left + (right - left) * (value - arr[left]) / (arr[right] - arr[left]);
		int midv = arr[mid];
		if (value > midv) {
			return Ivs(arr, mid + 1, right, value);
		} else if (value < midv) {
			return Ivs(arr, left, midv, value);
		} else {
			return mid;
		}
	}

	public static void main(String[] args) {
		int[] arr = new int[100];
		for (int i = 0; i < 100; i++) {
			arr[i] = i + 1;
		}
		int i = Ivs(arr, 0, arr.length - 1, 4);
		if (i == -1) {
			System.out.println("未找到");
		} else {
			System.out.println("在第" + (i + 1) + "个");
		}

	}

}
