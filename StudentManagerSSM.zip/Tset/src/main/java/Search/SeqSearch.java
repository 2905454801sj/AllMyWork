package Search;

public class SeqSearch {
	// 线性查找
	public static int seq(int[] arr, int value) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == value) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		int[] arr = { 5, 4, 1, 7, 8, 3 };
		int index = seq(arr, 3);
		if (index == -1) {
			System.out.println("未找到");
		} else {
			System.out.println("在第" + (seq(arr, 3) + 1) + "个");
		}
	}

}
