package Sort;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import javax.xml.crypto.Data;

//冒泡排序

public class BubbleSort {
	public static void bubble(int[] array) {
		System.out.println(Arrays.toString(array));
		// 第一次排序将最大的数放在最后
		int temp = 0;
		boolean flag = false;// 标识是否进行过排序
		for (int j = 1; j < array.length - 1; j++) {
			for (int i = 0; i < array.length - j; i++) {
				if (array[i] > array[i + 1]) {
					flag = true;
					temp = array[i];
					array[i] = array[i + 1];
					array[i + 1] = temp;
				}
			}
		}
		if (!flag) {
			System.out.println("不需要排序");
		} else {
			System.out.println("排序后");
			System.out.println(Arrays.toString(array));
		}
	}

	public static void main(String[] args) {
		// 测试冒泡排序的速度O(n^2),创建一个80000个数据的数组
		/*
		 * int[] arr = new int[8000]; for (int i = 0; i < 8000; i++) { arr[i] = (int)
		 * (Math.random() * 800000);// random产生的是0-1之间的小数 }
		 * 
		 * Date data1 = new Date(); SimpleDateFormat simpleDateFormat = new
		 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); String string1 =
		 * simpleDateFormat.format(data1); System.out.println("排序前时间为: " + data1);
		 * 
		 * bubble(arr);
		 * 
		 * Date data2 = new Date(); String string2 = simpleDateFormat.format(data2);
		 * System.out.println("排序后时间为: " + data2);
		 */
		int[] array = { -1, 3, 9, 0, 4, 6, 8, 7 };
		bubble(array);
	}

}
