package Sort;

import java.util.Arrays;

public class HeapSort {
    //编写堆排序方法
    public static void heap(int[] arr){
        System.out.println("堆排序");
        int temp=0;
        //降序
        /*for(int i=arr.length/2-1;i>=0;i--){
            adjust(arr,i,arr.length);
        }*/
        //升序
        for(int j=arr.length-1;j>0;j--){
            temp=arr[j];
            arr[j]=arr[0];
            arr[0]=temp;
            adjust(arr,0,j);
        }
        System.out.println(Arrays.toString(arr));
    }

    /**
     *
     * @param arr 数组
     * @param i 表示非叶子节点在数组中的下标
     * @param length 对多少个元素进行调整，递减
     */
    public static void adjust(int[] arr,int i,int length){
        int temp=arr[i];//取出当前元素保存在临时变量
        for(int k=i*2+1;k<length;k=k*2+1){//k=i*2+1表示的是左子节点
            if(k+1<length&&arr[k]<arr[k+1]){//左子节点小于右子节点
                k++;
            }
            if(arr[k]>temp){//子节点大于父节点
                arr[i]=arr[k];
                i=k;//i指向k，继续循环
            }else{
                break;
            }
        }
        arr[i]=temp;
    }
    public static void main(String[] args){
        int arr[]={3,1,5,9,4,8,7};
        heap(arr);
    }
}
