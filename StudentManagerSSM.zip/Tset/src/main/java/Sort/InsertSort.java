package Sort;

import java.util.Arrays;

public class InsertSort {
	// 插入排序
	public static void insert(int[] arr) {
		// 定义待插入的数
		for (int i = 0; i < arr.length - 1; i++) {
			int insertvalue = arr[i + 1];
			int insertIndex = i;
			while (insertIndex >= 0 && insertvalue < arr[insertIndex]) {
				// 1保证给insertvalue插入时不越界
				// 2说明带插入的数没找到适当的位置
				// 就需要将arr[insertIndex]后移
				arr[insertIndex + 1] = arr[insertIndex];
				arr[insertIndex]=insertvalue;
				insertIndex--;
			}
			// 当退出循环时，说明找到位置
			// 判断是否需要复制，提高效率
			if (insertIndex + 1 != i) {
				arr[insertIndex + 1] = insertvalue;
			}
			System.out.println("第" + (i + 1) + "次排序");
			System.out.println(Arrays.toString(arr));
		}
	}

	public static void main(String[] args) {
		int[] arr = { 121, 45, 30, 76, 66 };
		insert(arr);
	}

}
