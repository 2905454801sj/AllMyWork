package Sort;

import java.util.Arrays;

public class QuickSort {
	// 快速排序
	public static void queue(int[] arr, int left, int right) {
		int l = left;
		int r = right;
		// pivot中轴
		int pivot = arr[(left + right) / 2];
		int temp = 0;
		while (l < r) {
			// 是让比pivot小的放到左边，大的放在右边
			while (arr[l] < pivot) {
				l += 1;
			}
			while (arr[r] > pivot) {
				r -= 1;
			}
			// 如果l>=r成立，说明排序完成
			if (l >= r) {
				break;
			}
			temp = arr[l];
			arr[l] = arr[r];
			arr[r] = temp;
			if (arr[l] == pivot) {
				r--;
			}
			if (arr[r] == pivot) {
				l++;
			}
		}
		// 若l=r，必须执行以下，否则栈溢出
		if (l == r) {
			r--;
			l++;
		}
		// 向左递归
		if (left < r) {
			queue(arr, left, r);
		}
		if (right > l) {
			queue(arr, l, right);
		}
	}

	public static void main(String[] args) {
		int[] arr = { 5, 2, 6, -1, 0, 3, 8, 7, 4, 1 };
		queue(arr, 0, arr.length - 1);
		System.out.println(Arrays.toString(arr));
	}

}
