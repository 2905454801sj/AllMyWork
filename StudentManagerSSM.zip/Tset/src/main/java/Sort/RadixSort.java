package Sort;

import java.util.Arrays;

public class RadixSort {
	// 基数排序,空间换时间
	// 定义一个二维数组，表示10个桶，一个桶就是一个一位数组
	// 放入数据时，数据溢出，将每一个桶大小定义为arr.length
	public static void Radix(int[] arr) {
		int[][] bucket = new int[10][arr.length];
		// 定义一个一位数组来记录各个桶放入数据的个数
		int[] bucketcount = new int[10];
		// 得到最大数的位数
		int max = arr[0];
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] > max) {
				max = arr[i];
			}
		}
		// 得到位数
		int length = (max + "").length();
		for (int z = 0; z < length; z++) {
			for (int j = 0; j < arr.length; j++) {
				int a1 = (int) (arr[j] / (1 * Math.pow(10, z)) % 10);// 取出个/十/百位数
				bucket[a1][bucketcount[a1]] = arr[j];
				bucketcount[a1]++;
			}
			// 按照桶的顺序将数据放入原来的数组中
			int index = 0;
			for (int k = 0; k < bucketcount.length; k++) {
				// 如果桶中有数据，才放入到原数组
				if (bucketcount[k] != 0) {
					for (int l = 0; l < bucketcount[k]; l++) {
						// 取出数字放入原数组
						arr[index] = bucket[k][l];
						index++;
					}
				}
				// 处理结束需要将数组置0
				bucketcount[k] = 0;
			}
			System.out.println("第" + (z + 1) + "次排序：" + Arrays.toString(arr));
		}
	}

	public static void main(String[] args) {
		int[] arr = { 109, 12, 1, 234, 67, 90, 865 };
		Radix(arr);
	}

}
