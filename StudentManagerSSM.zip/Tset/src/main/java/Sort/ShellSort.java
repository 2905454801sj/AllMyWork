package Sort;

import java.util.Arrays;

public class ShellSort {
//希尔排序
	public static void shell1(int[] arr) {
		// 交换法
		int temp = 0;
		int a = arr.length / 2;
		for (; a > 0; a /= 2) {
			for (int i = a; i < arr.length; i++) {
				// 先将数组一分为二，遍历各组中所有的元素
				for (int j = i - a; j >= 0; j -= a) {
					// 当前元素大于步数之后的元素，则交换
					if (arr[j] > arr[j + a]) {
						temp = arr[j];
						arr[j] = arr[j + a];
						arr[j + a] = temp;
					}
				}
			}
		}
		System.out.println(Arrays.toString(arr));
	}

	public static void shell2(int[] arr) {
		// 移动法,效率更高
		int count = 0;
		for (int a = arr.length / 2; a > 0; a /= 2) {
			// 从第a个元素开始，逐个对其坐在的组直接插入
			for (int i = a; i < arr.length; i++) {
				int j = i;
				int temp = arr[j];
				if (arr[j] < arr[j - a]) {
					while (j - a >= 0 && temp < arr[j - a]) {
						// 移动
						arr[j] = arr[j - a];
						j -= a;
					}
					// 退出循环说明找到位置
					arr[j] = temp;
				}
				count++;
				System.out.println("第" + count + "次");
				System.out.println(Arrays.toString(arr));
			}
		}
		// System.out.println(Arrays.toString(arr));
	}

	public static void main(String[] args) {
		int[] arr = { 2, 9, 0, 1, 4, 6, 8, 7, 5, 3 };
		// shell1(arr);
		shell2(arr);
	}

}
