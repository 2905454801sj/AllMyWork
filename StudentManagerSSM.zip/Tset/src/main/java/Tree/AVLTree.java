package Tree;
class AVLt{
    private AVLNode root;
    public AVLNode getRoot(){
        return root;
    }
    public AVLNode search(int value){
        if(root==null){
            return null;
        }else{
            return root.search(value);
        }
    }
    public AVLNode searchParent(int value){
        if(root==null){
            return null;
        }else{
            return root.searchParent(value);
        }
    }
    public int delRightTree(AVLNode node){
        AVLNode a=node;
        while(a.left!=null){
            a=a.left;
        }
        delete(a.value);
        return a.value;
    }
    public void delete(int value){
        if(root==null){
            return;
        }else{
            AVLNode node=search(value);
            if(node==null){
                return;
            }
            if(root.left==null&root.right==null){
                root=null;
                return;
            }
            AVLNode parent=searchParent(value);
            if(node.left==null&&node.right==null){
                if(parent.left.value==value&&parent.left!=null){
                    parent.left=null;
                }else if(parent.right!=null&&parent.right.value==value){
                    parent.right=null;
                }
            }else if(node.left!=null&&node.right!=null){
                int min=delRightTree(node.right);
                node.value=min;
            }else{
                if(node!=null){
                    if(parent!=null) {
                        if (parent.left.value == value) {
                            parent.left = node.left;
                        } else {
                            parent.right = node.left;
                        }
                    }else{
                        root=node.left;
                    }
                }else{
                    if(parent!=null) {
                        if (parent.left.value == value) {
                            parent.left = node.right;
                        } else {
                            parent.right = node.right;
                        }
                    }else{
                        root=node.right;
                    }
                }
            }
        }
    }
    public void add(AVLNode node){
        if(root==null){
            root=node;
        }else {
            root.add(node);
        }
    }
    public void infixOrder(){
        if(root!=null){
            root.infixOrder();
        }else{
            System.out.println("树为空");
        }
    }
}
class AVLNode{
    int value;
    AVLNode left;
    AVLNode right;
    public AVLNode(int value){
        this.value=value;
    }
    //表示树的高度
    public int height(){
        return Math.max(left==null ? 0:left.height(), right==null ? 0:right.height())+1;
    }
    public int leftHeight(){
        if(left==null) {
            return 0;
        }
        return left.height();
    }
    public int rightHeight(){
        if(right==null){
            return 0;
        }
        return right.height();
    }
    //左旋转方法
    private void leftRetate(){
        AVLNode avlNode = new AVLNode(value);
        avlNode.left=left;
        avlNode.right=right.left;
        value=right.value;
        right=right.right;
        left=avlNode;
    }
    //右旋转方法
    private void rightRotate(){
        AVLNode avlNode = new AVLNode(value);
        avlNode.right=right;
        avlNode.left=left.right;
        value=left.value;
        left=left.left;
        right=avlNode;
    }
    public AVLNode searchParent(int value) {
        if((this.left!=null&&this.left.value==value)||
                (this.right!=null&&this.right.value==value)){
            return this;
        }else{
            if(value<this.value&&this.left!=null){
                return this.left.searchParent(value);
            }else if(value>=this.value&&this.right!=null){
                return this.right.searchParent(value);
            }else {
                return null;
            }
        }
    }

    protected void add(AVLNode node) {
        if(node==null){
            return;
        }
        if(node.value<this.value){
            if(this.left==null){
                this.left=node;
            }else{
                this.left.add(node);
            }
        }else{
            if(this.right==null){
                this.right=node;
            }else{
                this.right.add(node);
            }
        }
        if(rightHeight()-leftHeight()>1) {
            if(right!=null&&right.leftHeight()>right.rightHeight()) {
                right.rightRotate();
                leftRetate();
            }else{
                leftRetate();
            }
            return;
        }
        if(leftHeight()-rightHeight()>1) {
            if(left!=null&&left.rightHeight()>left.leftHeight()) {
                left.leftRetate();
                rightRotate();
            }else{
                rightRotate();
            }
            //return;
        }
    }

    public void infixOrder() {
        if(this.left!=null){
            this.left.infixOrder();
        }
        System.out.println(this);
        if(this.right!=null){
            this.right.infixOrder();
        }
    }

    public AVLNode search(int value) {
        if(value==this.value){
            return this;
        }else if(value<this.value){
            if(this.left==null) {
                return null;
            }
            return this.left.search(value);
        }else{
            if(this.right==null){
                return null;
            }
            return this.right.search(value);
        }
    }
}
public class AVLTree {
    public static void main(String[] args){
        int[] arr={3,2,4,7,5,9,10,23};
        AVLt avlTree = new AVLt();
        for(int i=0;i<arr.length;i++){
            avlTree.add(new AVLNode(arr[i]));
        }
        System.out.println("中序遍历");
        avlTree.infixOrder();
        System.out.println(avlTree.getRoot().height());
        System.out.println(avlTree.getRoot().leftHeight());
        System.out.println(avlTree.getRoot().rightHeight());
    }
}
