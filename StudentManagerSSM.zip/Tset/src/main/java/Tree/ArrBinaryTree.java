package Tree;

public class ArrBinaryTree {
	static class BinaryTree {
		private int[] arr;

		public BinaryTree(int[] arr) {
			super();
			this.arr = arr;
		}

		// 重载preOrder方法
		public void preOrder() {
			preOrder(0);
		}

		// 顺序存储
		public void preOrder(int index) {
			if (arr == null || arr.length == 0) {
				System.out.println("当前数组为空");
			}
			System.out.println("第  " + index + "  个节点为  " + arr[index]);
			if (index * 2 + 1 < arr.length) {
				preOrder(index * 2 + 1);
			}
			if (index * 2 + 2 < arr.length) {
				preOrder(index * 2 + 2);
			}
		}
	}

	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7 };
		BinaryTree a = new BinaryTree(arr);
		a.preOrder();
	}

}
