package Tree;

public class BinarySortTree {
    static class BinaryST{
        private Node root;
        public Node search(int value){
            if(root==null){
                return null;
            }else{
                return root.search(value);
            }
        }
        public Node searchParent(int value){
            if(root==null){
                return null;
            }else{
                return root.searchParent(value);
            }
        }
        public int delRightTree(Node node){
            Node a=node;
            while(a.left!=null){
                a=a.left;
            }
            delete(a.value);
            return a.value;
        }
        public void delete(int value){
            if(root==null){
                return;
            }else{
                Node node=search(value);
                if(node==null){
                    return;
                }
                if(root.left==null&root.right==null){
                    root=null;
                    return;
                }
                Node parent=searchParent(value);
                if(node.left==null&&node.right==null){
                    if(parent.left.value==value&&parent.left!=null){
                        parent.left=null;
                    }else if(parent.right!=null&&parent.right.value==value){
                        parent.right=null;
                    }
                }else if(node.left!=null&&node.right!=null){
                    int min=delRightTree(node.right);
                    node.value=min;
                }else{
            if(node!=null){
                if(parent!=null) {
                    if (parent.left.value == value) {
                        parent.left = node.left;
                    } else {
                        parent.right = node.left;
                    }
                }else{
                    root=node.left;
                }
                }else{
                if(parent!=null) {
                    if (parent.left.value == value) {
                        parent.left = node.right;
                    } else {
                        parent.right = node.right;
                    }
                }else{
                    root=node.right;
                }
                }
                }
            }
        }
        public void add(Node node){
            if(root==null){
                root=node;
            }else {
                root.add(node);
            }
        }
        public void infixOrder(){
            if(root!=null){
                root.infixOrder();
            }else{
                System.out.println("树为空");
            }
        }
    }
    static class Node{
    int value;
    Node left;
    Node right;
    public Node(int value){
        this.value=value;
    }
    public Node search(int value){
        if(value==this.value){
            return this;
        }else if(value<this.value){
            if(this.left==null) {
                return null;
            }
                return this.left.search(value);
        }else{
            if(this.right==null){
                return null;
            }
            return this.right.search(value);
        }
    }
    public Node searchParent(int value){
        if((this.left!=null&&this.left.value==value)||
                (this.right!=null&&this.right.value==value)){
            return this;
        }else{
            if(value<this.value&&this.left!=null){
                return this.left.searchParent(value);
            }else if(value>=this.value&&this.right!=null){
                return this.right.searchParent(value);
            }else {
                return null;
            }
        }
    }
        @Override
        public String toString() {
            return "Node{" +
                    "value=" + value +
                    '}';
        }

        //添加节点的方法
        public void add(Node node){
            if(node==null){
                return;
            }
            if(node.value<this.value){
                if(this.left==null){
                    this.left=node;
                }else{
                    this.left.add(node);
                }
            }else{
                if(this.right==null){
                    this.right=node;
                }else{
                    this.right.add(node);
                }
            }
        }
        public void infixOrder(){
        if(this.left!=null){
            this.left.infixOrder();
        }
        System.out.println(this);
        if(this.right!=null){
            this.right.infixOrder();
        }
        }
}
    public static void main(String[] args){
        int[] arr={3,5,4,1,9,7,8,2,6};
        BinaryST binarySortTree = new BinaryST();
        for(int i=0;i<arr.length;i++){
            binarySortTree.add(new Node(arr[i]));
        }
        System.out.println("中序遍历");
        binarySortTree.delete(8);
        binarySortTree.infixOrder();
    }
}
