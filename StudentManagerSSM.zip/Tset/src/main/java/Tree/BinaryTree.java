package Tree;

//定义binarytree 二叉树
class BinaryTree {
	private static HeroNode rootHeroNode;

	public void setRoot(HeroNode rootHeroNode) {
		this.rootHeroNode = rootHeroNode;
	}

	public void preOrder() {
		if (this.rootHeroNode != null) {
			this.rootHeroNode.preOrder();
		} else {
			System.out.println("当前二叉树为空");
		}
	}

	public void infixOrder() {
		if (this.rootHeroNode != null) {
			this.rootHeroNode.infixOrder();
		} else {
			System.out.println("当前二叉树为空");
		}
	}

	public void postOrder() {
		if (this.rootHeroNode != null) {
			this.rootHeroNode.postOrder();
		} else {
			System.out.println("当前二叉树为空");
		}
	}

	public void delete(int no) {
		if (rootHeroNode != null) {
			if (rootHeroNode.getNo() == no) {
				rootHeroNode = null;
			} else {
				rootHeroNode.delete(no);
			}
		} else {
			System.out.print("二叉树为空");
		}
	}

	public static HeroNode preSearch(int no) {
		if (rootHeroNode != null) {
			return rootHeroNode.preSearch(no);
		} else {
			return null;
		}
	}

	public HeroNode infixSearch(int no) {
		if (rootHeroNode != null) {
			return rootHeroNode.infixSearch(no);
		} else {
			return null;
		}
	}

	public HeroNode postSearch(int no) {
		if (rootHeroNode != null) {
			return rootHeroNode.postSearch(no);
		} else {
			return null;
		}
	}

//创建节点
	static class HeroNode {
		private int no;
		private String nameString;
		private HeroNode right;
		private HeroNode left;

		public HeroNode(int no, String nameString) {
			this.no = no;
			this.nameString = nameString;
		}

		public int getNo() {
			return no;
		}

		public void setNo(int no) {
			this.no = no;
		}

		public String getNameString() {
			return nameString;
		}

		public void setNameString(String nameString) {
			this.nameString = nameString;
		}

		public HeroNode getRight() {
			return right;
		}

		public void setRight(HeroNode right) {
			this.right = right;
		}

		public HeroNode getLeft() {
			return left;
		}

		public void setLeft(HeroNode left) {
			this.left = left;
		}

		@Override
		public String toString() {
			return "HeroNode [no=" + no + ", nameString=" + nameString + "]";
		}

		// 编写前序遍历方法
		public void preOrder() {
			System.out.println(this);// 先输出父节点
			// 递归向左子树前序遍历
			if (this.left != null) {
				this.left.preOrder();
			}
			// 递归向右子树前序遍历
			if (this.right != null) {
				this.right.preOrder();
			}
		}

		// 中序遍历
		public void infixOrder() {
			if (this.left != null) {
				this.left.infixOrder();
			}
			// 输出父节点
			System.out.println(this);
			if (this.right != null) {
				this.right.infixOrder();
			}
		}

		// 后序遍历
		public void postOrder() {
			if (this.left != null) {
				this.left.postOrder();
			}
			if (this.right != null) {
				this.right.postOrder();
			}
			System.out.println(this);
		}

		public void delete(int no) {
			if (this.left != null && this.left.no == no) {
				this.left = null;
				return;
			}
			if (this.right != null && this.right.no == no) {
				this.right = null;
				return;
			}
			if (this.left != null) {
				this.left.delete(no);
			}
			if (this.right != null) {
				this.right.delete(no);
			}
		}

		// 前序查找
		public HeroNode preSearch(int no) {
			// 比较当前节点是不是
			if (this.no == no) {
				return this;
			}
			HeroNode a = null;
			if (this.left != null) {
				a = this.left.preSearch(no);
			}
			if (a != null) {
				return a;
			}
			if (this.right != null) {
				a = this.right.preSearch(no);
			}
			return a;
		}

		// 中序查找
		public HeroNode infixSearch(int no) {
			HeroNode a = null;
			if (this.left != null) {
				a = this.left.infixSearch(no);
			}
			if (a != null) {
				return a;
			}
			if (this.no == no) {
				return this;
			}
			if (this.right != null) {
				a = this.right.infixSearch(no);
			}
			return a;
		}

		// 后续查找
		public HeroNode postSearch(int no) {
			HeroNode a = null;
			if (this.left != null) {
				a = this.left.postSearch(no);
			}
			if (a != null) {
				return a;
			}
			if (this.right != null) {
				a = this.right.postSearch(no);
			}
			if (a != null) {
				return a;
			}
			if (this.no == no) {
				return this;
			}
			return a;
		}
	}

	public static void main(String[] args) {
		// 创建二叉树
		BinaryTree binaryTree = new BinaryTree();
		HeroNode hero1 = new HeroNode(1, "s1");
		HeroNode hero2 = new HeroNode(2, "s2");
		HeroNode hero3 = new HeroNode(3, "s3");
		HeroNode hero4 = new HeroNode(4, "s4");
		HeroNode hero5 = new HeroNode(5, "s5");
		binaryTree.setRoot(hero1);
		hero1.setRight(hero3);
		hero1.setLeft(hero2);
		hero3.setRight(hero5);
		hero3.setLeft(hero4);

		System.out.println("前序遍历");
		binaryTree.preOrder();
		System.out.println("中序遍历");
		binaryTree.infixOrder();
		System.out.println("后序遍历");
		binaryTree.postOrder();
		System.out.println("前序查找");
		HeroNode a1 = BinaryTree.preSearch(3);
		if (a1 != null) {
			System.out.printf("id = %d,name = %s\n", a1.getNo(), a1.getNameString());
		} else {
			System.out.println("未找到");
		}
		System.out.println("中序查找");
		HeroNode a2 = BinaryTree.preSearch(2);
		if (a2 != null) {
			System.out.printf("id = %d,name = %s\n", a2.getNo(), a2.getNameString());
		} else {
			System.out.println("未找到");
		}
		System.out.println("前序查找");
		HeroNode a3 = BinaryTree.preSearch(1);
		if (a3 != null) {
			System.out.printf("id = %d,name = %s\n", a3.getNo(), a3.getNameString());
		} else {
			System.out.println("未找到");
		}
		System.out.println("\n删除hero3节点");
		hero1.delete(3);
		binaryTree.preOrder();
	}
}
