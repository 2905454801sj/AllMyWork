package Tree;

//import sun.jvm.hotspot.gc.z.ZCollectedHeap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//为了让Node对象持续排序Collection集合排序
//让Node实现Comparable接口
class Node implements Comparable<Node> {
    int value;
    Node right;
    Node left;
    //前序遍历
    public void preOrder(){
        System.out.println(this);
        if(this.left!=null){
            this.left.preOrder();
        }
        if(this.right!=null){
            this.right.preOrder();
        }
    }
    public Node(int value){
        this.value=value;
    }
    @Override
    public String toString() {
        return "Node{" +
                "value=" + value +
                '}';
    }

    @Override
    public int compareTo(Node o) {
        //从小到大排序
        return this.value-o.value;
    }
}
public class HuffmanTree {
    public static Node CreateHT(int[] arr){
        //遍历数组
        //将arr的每个元素构成一个Node
        //将Node放入ArrayList便于添加
        List<Node> nodes=new ArrayList<Node>();
        for(int value:arr){
            nodes.add((new Node(value)));
        }
        while(nodes.size()>1) {
            //从小到大排序
            Collections.sort(nodes);
            System.out.println(nodes);
            //取出权值最小的数
            Node leftnode = nodes.get(0);
            Node rightnode = nodes.get(1);
            //构建新的二叉树
            Node parent = new Node(leftnode.value + rightnode.value);
            parent.left = leftnode;
            parent.right = rightnode;
            //删除二叉树
            nodes.remove(leftnode);
            nodes.remove(rightnode);
            //将parent加入到nodes
            nodes.add(parent);
        }
        return nodes.get(0);
    }
    public static void preOrder(Node root){
        if(root!=null){
            root.preOrder();
        }else{
            System.out.println("该树为空");
        }
    }
    public static void main(String[] args){
        int[] arr={2,8,7,0,9,5,1,4,3,6};
        Node node=CreateHT(arr);
        preOrder(node);
    }
}
