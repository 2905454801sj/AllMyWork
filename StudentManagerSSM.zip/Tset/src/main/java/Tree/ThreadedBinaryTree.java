package Tree;

public class ThreadedBinaryTree {

    static class ThBinaryTree {
        //为了实现线索化，需要创建要给指向当前节点的前驱节点的指针
        //在递归进行线索化时，pre总是保留前一个节点
        private HeroNode1 pre=null;
        private HeroNode1 rootHeroNode;
        public void threadedNodes(){
            this.threadedNodes(rootHeroNode);
        }
        //遍历线索化二叉树的方法
        public void thList(){
            HeroNode1 node=rootHeroNode;
            while(node!=null){
                //循环的找到leftType=1的节点
                while(node.getLeftType()==0){
                    node=node.getLeft();
                }
                System.out.println(node);
                //如果当前的节点右指针指向的是后继节点，就一直输出
                while(node.getRightType()==1){
                    node =node.getRight();
                    System.out.println(node);
                }
                node=node.getRight();
            }
        }
        public void setRoot(HeroNode1 rootHeroNode) {
            this.rootHeroNode = rootHeroNode;
        }
        //编写对二叉树进行中序线索化的方法
        public void threadedNodes(HeroNode1 heroNode1){
            //如果node==null,直接退出
            if(heroNode1==null){
                return ;
            }
            //先线索化左子树，再线索化当前结点，再线索化右子树
            threadedNodes(heroNode1.getLeft());
            if(heroNode1.getLeft()==null){
                heroNode1.setLeft(pre);
                heroNode1.setLeftType(1);
            }
            if(pre!=null&&pre.getRight()==null){
                pre.setRight(heroNode1);
                pre.setRightType(1);
            }
            pre=heroNode1;
            threadedNodes(heroNode1.getRight());
        }
    }
    }
    class HeroNode1 {
        private int no;
        private String nameString;
        private HeroNode1 right;
        private HeroNode1 left;
        //如果lefttype=0，表示指向左子树，如果1表示前驱节点
        //如果righttype=0，表示指向右子树，如果1表示前驱节点
        private  int leftType;
        private int rightType;

        public int getLeftType() {
            return leftType;
        }

        public void setLeftType(int leftType) {
            this.leftType = leftType;
        }

        public int getRightType() {
            return rightType;
        }

        public void setRightType(int rightType) {
            this.rightType = rightType;
        }

        public HeroNode1(int no, String nameString) {
            this.no = no;
            this.nameString = nameString;
        }

        public int getNo() {
            return no;
        }

        public void setNo(int no) {
            this.no = no;
        }

        public String getNameString() {
            return nameString;
        }

        public void setNameString(String nameString) {
            this.nameString = nameString;
        }

        public HeroNode1 getRight() {
            return right;
        }

        public void setRight(HeroNode1 right) {
            this.right = right;
        }

        public HeroNode1 getLeft() {
            return left;
        }

        public void setLeft(HeroNode1 left) {
            this.left = left;
        }

        @Override
        public String toString() {
            return "HeroNode1 [no=" + no + ", nameString=" + nameString + "]";
        }

        // 编写前序遍历方法
        public void preOrder() {
            System.out.println(this);// 先输出父节点
            // 递归向左子树前序遍历
            if (this.left != null) {
                this.left.preOrder();
            }
            // 递归向右子树前序遍历
            if (this.right != null) {
                this.right.preOrder();
            }
        }

        // 中序遍历
        public void infixOrder() {
            if (this.left != null) {
                this.left.infixOrder();
            }
            // 输出父节点
            System.out.println(this);
            if (this.right != null) {
                this.right.infixOrder();
            }
        }

        // 后序遍历
        public void postOrder() {
            if (this.left != null) {
                this.left.postOrder();
            }
            if (this.right != null) {
                this.right.postOrder();
            }
            System.out.println(this);
        }

        public void delete(int no) {
            if (this.left != null && this.left.no == no) {
                this.left = null;
                return;
            }
            if (this.right != null && this.right.no == no) {
                this.right = null;
                return;
            }
            if (this.left != null) {
                this.left.delete(no);
            }
            if (this.right != null) {
                this.right.delete(no);
            }
        }

        // 前序查找
        public HeroNode1 preSearch(int no) {
            // 比较当前节点是不是
            if (this.no == no) {
                return this;
            }
            HeroNode1 a = null;
            if (this.left != null) {
                a = this.left.preSearch(no);
            }
            if (a != null) {
                return a;
            }
            if (this.right != null) {
                a = this.right.preSearch(no);
            }
            return a;
        }

        // 中序查找
        public HeroNode1 infixSearch(int no) {
            HeroNode1 a = null;
            if (this.left != null) {
                a = this.left.infixSearch(no);
            }
            if (a != null) {
                return a;
            }
            if (this.no == no) {
                return this;
            }
            if (this.right != null) {
                a = this.right.infixSearch(no);
            }
            return a;
        }

        // 后续查找
        public HeroNode1 postSearch(int no) {
            HeroNode1 a = null;
            if (this.left != null) {
                a = this.left.postSearch(no);
            }
            if (a != null) {
                return a;
            }
            if (this.right != null) {
                a = this.right.postSearch(no);
            }
            if (a != null) {
                return a;
            }
            if (this.no == no) {
                return this;
            }
            return a;
        }
    public static void main(String[] args) {
            HeroNode1 sj=new HeroNode1(1,"sj");
        HeroNode1 a=new HeroNode1(4,"a");
        HeroNode1 b=new HeroNode1(9,"b");
        HeroNode1 c=new HeroNode1(8,"c");
        HeroNode1 d=new HeroNode1(13,"d");
        HeroNode1 e=new HeroNode1(7,"e");
        sj.setLeft(a);
        sj.setRight(b);
        a.setLeft(c);
        a.setRight(d);
        b.setLeft(e);
        ThreadedBinaryTree.ThBinaryTree thBinaryTree=new ThreadedBinaryTree.ThBinaryTree();
        thBinaryTree.setRoot(sj);
        thBinaryTree.threadedNodes();
        //测试
        HeroNode1 left=d.getLeft();
        HeroNode1 right=d.getRight();
        System.out.println(left);
        System.out.println(right);
        System.out.println("线索化遍历：");
        thBinaryTree.thList();
    }
}
