package com.jason.thread.Thread;

public class StackTrace1 {
    private StackTrace2 stackTrace2=new StackTrace2();
    public void test1(){
        stackTrace2.test2();
    }
}
