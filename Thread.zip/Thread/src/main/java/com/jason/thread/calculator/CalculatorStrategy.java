package com.jason.thread.calculator;

public interface CalculatorStrategy {
    double cal(double s,double b);
}
