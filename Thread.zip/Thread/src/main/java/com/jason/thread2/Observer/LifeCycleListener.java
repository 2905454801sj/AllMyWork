package com.jason.thread2.Observer;

public interface LifeCycleListener {
    void onEvent(ObserverRunnable.RunnableEvent event);
}
